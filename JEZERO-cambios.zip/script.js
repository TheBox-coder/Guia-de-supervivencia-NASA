const validation = window.JEZERO_VALIDATION;
const finiteValue = validation.finite;
const numericValue = validation.numeric;
const DATA_URL = 'mars-data.json';
const MARTIAN_RADIUS = 3389.5;
const DEM_RESOLUTION_KM = 0.2;
const LANDING = { lat: 18.44463, lon: 77.45088, name: 'Lugar de referencia: Perseverance', type: 'reference', required: false, dwellMin: 0 };
const GLOBAL_BBOX = { minLon: -180, maxLon: 180, minLat: -90, maxLat: 90 };
const HISTORY_KEY = 'mars-explorer-mission-history-v2';
const SETTINGS_KEY = 'jezero-settings-v29';
const DEFAULTS_KEY = 'jezero-operational-defaults-v29';
const PANEL_STATE_KEY = 'jezero-panel-state-v34';
const MAP_VIEW_KEY = 'jezero-map-view-v34';
const BASE_MAP_KEY = 'jezero-base-map-v34';
const JEZERO_UI_VERSION = 'V51';
const ALGORITHM_VERSION = '44.0';

let D;
let map, markerLayer, routeLayer, analysisLayer, molaLayer, imageryLayer, slopeLayer, roughnessLayer, landingLayer, knownLayer;
let missionPoints = [];
let selecting = false;
let currentMission = null;
let busy = false;
let lastCalculatedAt = null;
let activeLayerNames = new Set(['route','points','known','landing']);
let nomenclatureTimer = null;
let nomenclatureAbort = null;
let lastNomenclatureKey = '';
let nomenclatureRequestSeq = 0;
let derivedRefreshToken = 0;
let lastDerivedExtentKey = '';
const ROUTE_ANIMATION_KEY = 'jezero-route-animation-v43';
let routeFlowPhase = 0;
let routeAnimationFrame = 0;
let routeAnimationLastPaint = 0;
const reducedMotionQuery = window.matchMedia?.('(prefers-reduced-motion: reduce)') || {matches:false,addEventListener(){}};
let routeAnimationEnabled = localStorage.getItem(ROUTE_ANIMATION_KEY) !== 'off' && !reducedMotionQuery.matches;

const $ = id => document.getElementById(id);
const clamp = (v,a,b) => Math.min(b, Math.max(a,v));
const uiLang = () => window.JEZERO_I18N?.getLanguage?.() || 'es';
const ui = (es,en) => uiLang()==='en' ? en : es;
const themeInfo = () => window.JEZERO_THEMES?.getThemeInfo?.(uiLang()) || {key:'nasa-classic',label:ui('NASA Clásico','NASA Classic'),colors:{success:'#54d6a5',warning:'#ffc857',danger:'#fc3d21',accent2:'#55c8ff',accent:'#fc3d21',text:'#ffffff',bg:'#020611',primary2:'#1769d2'}};
const themeColors = () => window.JEZERO_THEMES?.getColors?.() || themeInfo().colors;

window.addEventListener('jezero:themechange',()=>{
  markerLayer?.changed?.(); routeLayer?.changed?.(); analysisLayer?.changed?.(); knownLayer?.changed?.(); landingLayer?.changed?.(); renderTerrainProfile(selectedMission?.());
  if(typeof updateSettingsSummary==='function') updateSettingsSummary();
});


function buildLayers(){
  const projection = ol.proj.get('EPSG:4326');
  const globalExtent = [-180,-90,180,90];
  const resolutions = Array.from({length:18},(_,z)=>0.703125/Math.pow(2,z));
  const tileGrid = new ol.tilegrid.TileGrid({extent:globalExtent,origin:[-180,90],resolutions,tileSize:256});
  const xyz = (url,maxZoom=12,extraClass='') => new ol.layer.Tile({
    className:`ol-layer jezero-base-map-layer ${extraClass}`.trim(),
    source:new ol.source.XYZ({projection,tileGrid:new ol.tilegrid.TileGrid({extent:globalExtent,origin:[-180,90],resolutions:resolutions.slice(0,maxZoom+1),tileSize:256}),maxZoom,wrapX:true,crossOrigin:'anonymous',url,transition:0}),
    opacity:1,zIndex:1
  });

  // Dos mapas base: imagen global Viking VIS y topografía MOLA/HRSC.
  // El DEM numérico se consulta por backend solo cuando el motor necesita
  // elevación/pendiente/rugosidad; cambiar el mapa base no cambia los cálculos del terreno.
  imageryLayer = xyz(D.map.realTile || 'https://trek.nasa.gov/tiles/Mars/EQ/Mars_Viking_MDIM21_ClrMosaic_global_232m/1.0.0/default/default028mm/{z}/{y}/{x}.jpg', Number(D.map.realMaxZoom||7), 'jezero-real-map-layer');
  imageryLayer.set('layerId','viking-vis-global');
  imageryLayer.setZIndex(1);
  imageryLayer.setVisible(true);

  molaLayer = xyz(D.map.globalTile, 12, 'jezero-topography-map-layer');
  molaLayer.set('layerId','mola-global');
  molaLayer.setZIndex(2);
  molaLayer.setOpacity(1);
  molaLayer.setVisible(false);

  slopeLayer = new ol.layer.Vector({source:new ol.source.Vector(),zIndex:4,visible:false});
  roughnessLayer = new ol.layer.Vector({source:new ol.source.Vector(),zIndex:5,visible:false});
  slopeLayer.set('layerId','slope-derived-mola');
  roughnessLayer.set('layerId','roughness-derived-mola');

  knownLayer = new ol.layer.Vector({
    source:new ol.source.Vector(),
    style: feature => knownLocationStyle(feature),
    zIndex:7,
    declutter:true
  });
  knownLayer.set('layerId','known-locations');
  landingLayer = new ol.layer.Vector({
    source:new ol.source.Vector(),
    style: feature => landingSiteStyle(feature),
    zIndex:8,
    declutter:true
  });
  landingLayer.set('layerId','landing-sites');
  markerLayer = new ol.layer.Vector({
    source:new ol.source.Vector(),
    style: feature => pointStyle(feature.get('kind'), feature.get('label'), feature),
    zIndex:10
  });
  routeLayer = new ol.layer.Vector({ source:new ol.source.Vector(), zIndex:11 });
  routeLayer.setStyle(feature => routeStyle(feature));
  analysisLayer = new ol.layer.Vector({source:new ol.source.Vector(),zIndex:15,style:feature=>analysisHighlightStyle(feature)});

  return { projection, layers:[imageryLayer,molaLayer,slopeLayer,roughnessLayer,knownLayer,landingLayer,routeLayer,markerLayer,analysisLayer] };
}
function setLayerStatus(name,text,cls='ready'){ const el=document.querySelector(`[data-layer-status="${name}"]`); if(el){el.textContent=text;el.className=`layerStatus ${cls}`;} }
function markLayerLoaded(name){ setLayerStatus(name,'ACTIVA','live'); }
function markLayerError(name){ setLayerStatus(name,'ERROR','error'); }
function markLayerLoading(name){ setLayerStatus(name,'CARGANDO…','loading'); }

async function prepareLayerSources(){
  setLayerStatus('mola','ACTIVA','live');
  setLayerStatus('slope','ACERCA PARA ANALIZAR','ready');
  setLayerStatus('roughness','ACERCA PARA ANALIZAR','ready');
  setLayerStatus('route','ACTIVA','live');
  setLayerStatus('points','ACTIVA','live');
}

function initMap(){
  const projection = ol.proj.get('EPSG:4326');
  const layers = buildLayers().layers;
  map = new ol.Map({ target:'map', layers, view:new ol.View({ projection, center:[Number(D.region?.lon)||0,Number(D.region?.lat)||0], zoom:Number(D.region?.zoom)||1.5, resolutions:Array.from({length:18},(_,z)=>0.703125/Math.pow(2,z)) }), controls:[] });
  window.JEZERO_IMAGERY?.install(map);
  map.on('pointermove', evt=>{ const c=evt.coordinate; if(c) $('coordReadout').textContent=`${formatLat(c[1])} · ${formatLon(c[0])}`; });
  map.on('singleclick', onMapClick);
  map.on('moveend', ()=>{ updateMapScale(); if(slopeLayer?.getVisible()||roughnessLayer?.getVisible()) refreshDerivedLayers(false); scheduleNomenclatureRefresh(); });
  $('zoomIn').onclick=()=>map.getView().setZoom(Math.min(17,map.getView().getZoom()+.7));
  $('zoomOut').onclick=()=>map.getView().setZoom(Math.max(0,map.getView().getZoom()-.7));
  $('center').onclick=()=>fitCurrentMission();
  updateMapScale();
  drawPointMarkers();
  populateReferenceLayers();
  startRouteAnimationLoop();
}
function hexAlpha(hex,alpha='33'){
  const value=String(hex||'').trim();
  return /^#[0-9a-f]{6}$/i.test(value) ? `${value}${alpha}` : value;
}
function pointStyle(kind,label,feature){
  const c=themeColors();
  const textColor=c.text||'#ffffff', bg=c.bg||'#020611';
  const accent=c.accent||'#8a5cff', success=c.success||'#54e0a6', warning=c.warning||'#ffc857';
  const name=String(feature?.get?.('name')||'').trim();
  const returnsHome=Boolean(feature?.get?.('returnsHome'));
  const styles=[];
  if(kind==='base'){
    styles.push(new ol.style.Style({image:new ol.style.RegularShape({points:6,radius:18.5,angle:Math.PI/6,displacement:[1,-2],fill:new ol.style.Fill({color:'rgba(0,0,0,.34)'})})}));
    styles.push(new ol.style.Style({
      image:new ol.style.RegularShape({points:6,radius:17,angle:Math.PI/6,fill:new ol.style.Fill({color:hexAlpha(success,'28')}),stroke:new ol.style.Stroke({color:hexAlpha(success,'75'),width:6})})
    }));
    styles.push(new ol.style.Style({
      image:new ol.style.RegularShape({points:6,radius:13,angle:Math.PI/6,fill:new ol.style.Fill({color:hexAlpha(bg,'ee')}),stroke:new ol.style.Stroke({color:success,width:2.8})}),
      text:new ol.style.Text({text:'⌂',offsetY:1,fill:new ol.style.Fill({color:success}),stroke:new ol.style.Stroke({color:bg,width:2}),font:'900 15px Inter,Segoe UI,sans-serif'})
    }));
    styles.push(new ol.style.Style({
      text:new ol.style.Text({text:returnsHome?ui('BASE · HOME','BASE · HOME'):ui('BASE','BASE'),offsetY:-29,fill:new ol.style.Fill({color:textColor}),stroke:new ol.style.Stroke({color:bg,width:5}),font:'900 10px "DM Mono",Consolas,monospace',padding:[2,5,2,5]})
    }));
    return styles;
  }
  if(kind==='finish'){
    styles.push(new ol.style.Style({image:new ol.style.RegularShape({points:6,radius:17.5,angle:Math.PI/6,displacement:[1,-2],fill:new ol.style.Fill({color:'rgba(0,0,0,.34)'})})}));
    styles.push(new ol.style.Style({image:new ol.style.RegularShape({points:6,radius:16,angle:Math.PI/6,fill:new ol.style.Fill({color:hexAlpha(warning,'24')}),stroke:new ol.style.Stroke({color:hexAlpha(warning,'72'),width:5})})}));
    styles.push(new ol.style.Style({
      image:new ol.style.RegularShape({points:6,radius:12,angle:Math.PI/6,fill:new ol.style.Fill({color:hexAlpha(bg,'ef')}),stroke:new ol.style.Stroke({color:warning,width:2.6})}),
      text:new ol.style.Text({text:String(label||'F'),offsetY:1,fill:new ol.style.Fill({color:warning}),stroke:new ol.style.Stroke({color:bg,width:2}),font:'950 11px "DM Mono",Consolas,monospace'})
    }));
    styles.push(new ol.style.Style({text:new ol.style.Text({text:ui('FIN','FINISH'),offsetY:-27,fill:new ol.style.Fill({color:textColor}),stroke:new ol.style.Stroke({color:bg,width:5}),font:'900 9px "DM Mono",Consolas,monospace'})}));
    return styles;
  }
  if(kind==='target' || kind==='science'){
    styles.push(new ol.style.Style({image:new ol.style.RegularShape({points:6,radius:17.5,angle:Math.PI/6,displacement:[1,-2],fill:new ol.style.Fill({color:'rgba(0,0,0,.32)'})})}));
    styles.push(new ol.style.Style({image:new ol.style.RegularShape({points:6,radius:16,angle:Math.PI/6,fill:new ol.style.Fill({color:hexAlpha(accent,'22')}),stroke:new ol.style.Stroke({color:hexAlpha(accent,'70'),width:5})})}));
    styles.push(new ol.style.Style({
      image:new ol.style.RegularShape({points:6,radius:12,angle:Math.PI/6,fill:new ol.style.Fill({color:hexAlpha(bg,'ed')}),stroke:new ol.style.Stroke({color:accent,width:2.7})}),
      text:new ol.style.Text({text:String(label||'•').padStart(2,'0'),offsetY:1,fill:new ol.style.Fill({color:textColor}),stroke:new ol.style.Stroke({color:bg,width:2}),font:'950 10px "DM Mono",Consolas,monospace'})
    }));
    if(name){
      styles.push(new ol.style.Style({text:new ol.style.Text({text:name.length>18?`${name.slice(0,17)}…`:name,offsetY:27,fill:new ol.style.Fill({color:hexAlpha(textColor,'e8')}),stroke:new ol.style.Stroke({color:bg,width:4}),font:'800 8.5px Inter,Segoe UI,sans-serif',padding:[1,3,1,3]})}));
    }
    return styles;
  }
  const color = kind==='reference' ? c.primary2 : kind==='optional' ? c.accent2 : accent;
  return new ol.style.Style({
    image:new ol.style.Circle({radius:8,fill:new ol.style.Fill({color}),stroke:new ol.style.Stroke({color:textColor,width:2})}),
    text:new ol.style.Text({ text:label||'P', offsetY:-20, fill:new ol.style.Fill({color:textColor}), stroke:new ol.style.Stroke({color:bg,width:4}), font:'800 11px "DM Mono",Consolas,monospace' })
  });
}
function routeFractionPoint(coords,fraction){
  if(!Array.isArray(coords)||coords.length<2)return null;
  const seg=[];let total=0;
  for(let i=1;i<coords.length;i++){
    const dx=coords[i][0]-coords[i-1][0],dy=coords[i][1]-coords[i-1][1],len=Math.hypot(dx,dy);
    seg.push({i,len,dx,dy});total+=len;
  }
  if(total<=0)return null;
  let target=total*Math.max(0,Math.min(1,fraction)),walk=0;
  for(const part of seg){
    if(walk+part.len>=target){
      const a=coords[part.i-1],b=coords[part.i],t=part.len?((target-walk)/part.len):0;
      return {coord:[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t],angle:Math.atan2(part.dy,part.dx)};
    }
    walk+=part.len;
  }
  const a=coords[coords.length-2],b=coords[coords.length-1];
  return {coord:b.slice(),angle:Math.atan2(b[1]-a[1],b[0]-a[0])};
}
function routeFlowStyles(feature,color,c){
  if(!routeAnimationEnabled || reducedMotionQuery.matches) return [];
  const geometry=feature?.getGeometry?.();
  const coords=geometry?.getCoordinates?.();
  if(!Array.isArray(coords)||coords.length<2)return [];
  const styles=[];
  const spacing=0.27;
  for(let i=0;i<3;i++){
    const fraction=(routeFlowPhase + i*spacing)%1;
    if(fraction<0.06 || fraction>0.94) continue;
    const sample=routeFractionPoint(coords,fraction); if(!sample) continue;
    const rotation=Math.PI/2-sample.angle;
    styles.push(new ol.style.Style({
      geometry:new ol.geom.Point(sample.coord),
      image:new ol.style.RegularShape({
        points:3,
        radius:4.8,
        angle:0,
        rotation,
        rotateWithView:true,
        fill:new ol.style.Fill({color:'rgba(0,0,0,.58)'}),
        stroke:new ol.style.Stroke({color:'rgba(0,0,0,.45)',width:1.6})
      })
    }));
    styles.push(new ol.style.Style({
      geometry:new ol.geom.Point(sample.coord),
      image:new ol.style.RegularShape({
        points:3,
        radius:3.7,
        angle:0,
        rotation,
        rotateWithView:true,
        fill:new ol.style.Fill({color}),
        stroke:new ol.style.Stroke({color:hexAlpha(c.text||'#fff','b8'),width:.8})
      })
    }));
  }
  return styles;
}
function routeStyle(feature){
  const selected=feature?.get?.('selected'),kind=feature?.get?.('kind');
  const c=themeColors();
  const color = kind==='risk' ? (c.success||'#54e0a6') : kind==='distance' ? (c.accent2||'#55b7ff') : (c.accent||'#8a5cff');
  if(selected){
    const corridor=kind==='risk'?hexAlpha(c.success||'#54e0a6','24'):kind==='distance'?hexAlpha(c.accent2||'#55b7ff','20'):hexAlpha(c.accent||'#8a5cff','22');
    const baseStyles=[
      new ol.style.Style({stroke:new ol.style.Stroke({color:'rgba(0,0,0,.58)',width:8,lineCap:'round',lineJoin:'round'})}),
      new ol.style.Style({stroke:new ol.style.Stroke({color:corridor,width:6,lineCap:'round',lineJoin:'round'})}),
      new ol.style.Style({stroke:new ol.style.Stroke({color,width:3.1,lineCap:'round',lineJoin:'round'})}),
      new ol.style.Style({stroke:new ol.style.Stroke({color:hexAlpha(c.text||'#fff','55'),width:.75,lineCap:'round',lineJoin:'round'})})
    ];
    return baseStyles.concat(routeFlowStyles(feature,color,c));
  }
  const dash=kind==='risk'?[3,8]:kind==='distance'?[9,7]:[6,7];
  return new ol.style.Style({ stroke:new ol.style.Stroke({color:hexAlpha(color,'8f'), width:1.7, lineDash:dash,lineCap:'round',lineJoin:'round'}) });
}

function setRouteAnimationEnabled(value,{persist=true,notify=true}={}){
  const requested=Boolean(value);
  routeAnimationEnabled=requested && !reducedMotionQuery.matches;
  if(persist) localStorage.setItem(ROUTE_ANIMATION_KEY, requested ? 'on' : 'off');
  const toggle=$('routeAnimationSetting');
  if(toggle) toggle.checked=requested && !reducedMotionQuery.matches;
  routeLayer?.changed?.();
  map?.render?.();
  if(notify){
    showToast(routeAnimationEnabled
      ? ui('Flujo animado de ruta activado.','Animated route flow enabled.')
      : ui('Animación de ruta desactivada.','Route animation disabled.'));
  }
}
function routeAnimationTick(now){
  routeAnimationFrame=requestAnimationFrame(routeAnimationTick);
  if(!routeAnimationEnabled || reducedMotionQuery.matches || document.hidden || !routeLayer?.getVisible?.()) return;
  const hasRoute=(routeLayer?.getSource?.()?.getFeatures?.()?.length||0)>0;
  if(!hasRoute) return;
  if(now-routeAnimationLastPaint<70) return; // ~14 fps: fluido y ligero
  routeAnimationLastPaint=now;
  routeFlowPhase=(now%3600)/3600;
  routeLayer.changed();
  map?.render?.();
}
function startRouteAnimationLoop(){
  if(routeAnimationFrame) return;
  routeAnimationFrame=requestAnimationFrame(routeAnimationTick);
}

function analysisHighlightStyle(feature){
  const c=themeColors();
  if(feature.get('analysisKind')==='segment') return [
    new ol.style.Style({stroke:new ol.style.Stroke({color:hexAlpha(c.warning||'#ffc857','55'),width:12,lineCap:'round',lineJoin:'round'})}),
    new ol.style.Style({stroke:new ol.style.Stroke({color:c.warning||'#ffc857',width:4.5,lineCap:'round',lineJoin:'round'})})
  ];
  return new ol.style.Style({
    image:new ol.style.Circle({radius:9,fill:new ol.style.Fill({color:c.warning||'#ffc857'}),stroke:new ol.style.Stroke({color:c.bg||'#020611',width:3})}),
    text:new ol.style.Text({text:feature.get('label')||'',offsetY:-19,fill:new ol.style.Fill({color:c.text||'#fff'}),stroke:new ol.style.Stroke({color:c.bg||'#020611',width:4}),font:'900 10px "DM Mono",Consolas,monospace'})
  });
}

function knownLocationStyle(feature){
  const c=themeColors();
  const zoom=Number(map?.getView?.().getZoom?.()||0);
  const minZoom=Number(feature.get('minZoom') ?? (feature.get('dynamicNomenclature') ? 3.0 : 1.8));
  if(zoom < minZoom) return null;
  const dynamic=Boolean(feature.get('dynamicNomenclature'));
  const color = feature.get('category')==='Cráter / antiguo lago' ? c.primary2 : c.accent2;
  const radius=dynamic ? 3.3 : 6.2;
  const image=dynamic
    ? new ol.style.Circle({radius,fill:new ol.style.Fill({color:hexAlpha(color,'d9')}),stroke:new ol.style.Stroke({color:hexAlpha(c.bg||'#020611','cc'),width:1})})
    : new ol.style.RegularShape({points:4,radius,angle:Math.PI/4,fill:new ol.style.Fill({color}),stroke:new ol.style.Stroke({color:c.text||'#ffffff',width:1.2})});
  return new ol.style.Style({
    image,
    text:new ol.style.Text({
      text:feature.get('label')||'',offsetY:dynamic?-11:-14,
      fill:new ol.style.Fill({color:c.text||'#ffffff'}),
      stroke:new ol.style.Stroke({color:c.bg||'#020611',width:dynamic?2.4:3}),
      font:`${dynamic?700:850} ${dynamic?8.5:9.5}px Inter,Segoe UI,sans-serif`,
      overflow:false,padding:[2,3,2,3]
    })
  });
}
function landingSiteStyle(feature){
  const c=themeColors();
  return new ol.style.Style({
    image:new ol.style.Circle({radius:7,fill:new ol.style.Fill({color:c.accent}),stroke:new ol.style.Stroke({color:c.text||'#ffffff',width:2.5})}),
    text:new ol.style.Text({text:feature.get('label')||'',offsetY:-14,fill:new ol.style.Fill({color:c.text||'#ffffff'}),stroke:new ol.style.Stroke({color:c.bg||'#020611',width:3}),font:'900 9px Inter,Segoe UI,sans-serif'})
  });
}
function populateReferenceLayers(){
  if(!D) return;
  const ks=knownLayer.getSource(); ks.clear();
  (D.knownLocations||[]).forEach(x=>ks.addFeature(new ol.Feature({
    geometry:new ol.geom.Point([x.lon,x.lat]), refKind:'known', refId:x.id, label:x.name,
    name:x.name, category:x.category, lat:x.lat, lon:x.lon, minZoom:x.minZoom, dynamicNomenclature:false, description:x.description, source:x.source, sourceUrl:x.sourceUrl
  })));
  const ls=landingLayer.getSource(); ls.clear();
  (D.landingSites||[]).forEach(x=>ls.addFeature(new ol.Feature({
    geometry:new ol.geom.Point([x.lon,x.lat]), refKind:'landing', refId:x.id, label:x.name,
    name:x.name, mission:x.mission, lat:x.lat, lon:x.lon, site:x.site, date:x.date, description:x.description, source:x.source, sourceUrl:x.sourceUrl
  })));
  const select=$('landingSiteSelect');
  if(select){ select.innerHTML='<option value="">Selecciona un sitio de aterrizaje…</option>'+(D.landingSites||[]).map(x=>`<option value="${escapeHtml(x.id)}">${escapeHtml(x.name)} · ${escapeHtml(x.site)}</option>`).join(''); }
}
function normalizeGazetteerLon(lon){
  let x=Number(lon);
  if(!Number.isFinite(x)) return 0;
  while(x>180) x-=360;
  while(x<-180) x+=360;
  return x;
}
function removeDynamicNomenclature(){
  const source=knownLayer?.getSource?.(); if(!source) return;
  source.getFeatures().filter(f=>f.get('dynamicNomenclature')).forEach(f=>source.removeFeature(f));
}
function addGazetteerFeatures(features=[]){
  const source=knownLayer?.getSource?.(); if(!source) return 0;
  removeDynamicNomenclature();
  let added=0;
  for(const x of features){
    const lat=Number(x.lat), lon=normalizeGazetteerLon(x.lon);
    if(!Number.isFinite(lat)||!Number.isFinite(lon)||!x.name) continue;
    const diameter=Number(x.diameterKm||0);
    const zoom=Number(map?.getView?.().getZoom?.()||3);
    const minZoom=diameter>=500?1.8:diameter>=150?2.4:diameter>=50?3.0:diameter>=15?3.8:4.6;
    source.addFeature(new ol.Feature({
      geometry:new ol.geom.Point([lon,lat]),refKind:'known',refId:`iau-${x.id||added}`,label:x.name,name:x.name,
      category:x.featureType||'Nomenclatura IAU',lat,lon,minZoom:Math.min(minZoom,Math.max(1.8,zoom-.35)),dynamicNomenclature:true,
      description:x.description||`${x.featureType||'Accidente geográfico'}${diameter?` · diámetro aprox. ${diameter.toFixed(1)} km`:''}.`,
      source:'USGS Gazetteer / IAU',sourceUrl:x.sourceUrl||'https://planetarynames.wr.usgs.gov/Page/MARS/target'
    }));
    added++;
  }
  knownLayer?.changed?.();
  return added;
}
async function refreshNomenclatureLabels(force=false){
  if(!map || !knownLayer?.getVisible?.()) return;
  const zoom=Number(map.getView().getZoom()||0);
  if(zoom<2.25){ removeDynamicNomenclature(); setLayerStatus('known','NOMBRES GLOBALES','live'); return; }
  const size=map.getSize(); if(!size) return;
  const extent=map.getView().calculateExtent(size);
  let west=normalizeGazetteerLon(extent[0]), east=normalizeGazetteerLon(extent[2]);
  const south=clamp(Number(extent[1]),-90,90), north=clamp(Number(extent[3]),-90,90);
  const rounded=v=>Math.round(v*4)/4;
  const key=[rounded(west),rounded(east),rounded(south),rounded(north),Math.floor(zoom*2)/2].join('|');
  if(!force && key===lastNomenclatureKey) return;
  lastNomenclatureKey=key;
  const seq=++nomenclatureRequestSeq;
  nomenclatureAbort?.abort?.(); nomenclatureAbort=new AbortController();
  setLayerStatus('known','CARGANDO IAU…','loading');
  const ranges = west<=east ? [[west,east]] : [[west,180],[-180,east]];
  try{
    const all=[];
    for(const [w,e] of ranges){
      const q=new URLSearchParams({west:String(w),east:String(e),south:String(south),north:String(north),zoom:String(zoom)});
      const res=await fetch(`${D?.map?.nomenclatureApi||'/api/mars-nomenclature'}?${q}`,{signal:nomenclatureAbort.signal,cache:'no-store'});
      if(!res.ok) throw new Error(`HTTP ${res.status}`);
      const payload=await res.json();
      if(Array.isArray(payload.features)) all.push(...payload.features);
    }
    if(seq!==nomenclatureRequestSeq) return;
    const dedup=[...new Map(all.map(x=>[String(x.id||x.name),x])).values()];
    const added=addGazetteerFeatures(dedup);
    setLayerStatus('known',added?`${added} NOMBRES`:'BASE LOCAL','live');
  }catch(err){
    if(err?.name==='AbortError') return;
    console.warn('USGS nomenclature unavailable; using local fallback.',err);
    removeDynamicNomenclature();
    setLayerStatus('known','BASE LOCAL','ready');
  }
}
function scheduleNomenclatureRefresh(delay=360){
  clearTimeout(nomenclatureTimer);
  nomenclatureTimer=setTimeout(()=>refreshNomenclatureLabels(false),delay);
}

function focusReference(refKind,refId){
  const layer=refKind==='landing'?landingLayer:knownLayer; const f=layer?.getSource().getFeatures().find(x=>x.get('refId')===refId); if(!f) return;
  map.getView().animate({center:f.getGeometry().getCoordinates(),zoom:Math.max(map.getView().getZoom(),2.8),duration:450}); showReferencePopup(f);
}
function showReferencePopup(feature){
  const box=$('mapInfo'); if(!box) return;
  const kind=feature.get('refKind');
  $('mapInfoKind').textContent=kind==='landing'?'SITIO DE ATERRIZAJE':'UBICACIÓN CONOCIDA';
  $('mapInfoTitle').textContent=feature.get('name');
  $('mapInfoMeta').textContent=kind==='landing'?`${feature.get('mission')} · ${feature.get('site')} · ${feature.get('date')}`:`${feature.get('category')} · punto de referencia`;
  $('mapInfoCoords').textContent=`${formatLat(feature.get('lat'))} · ${formatLon(feature.get('lon'))}`;
  $('mapInfoDescription').textContent=feature.get('description')||'';
  $('mapInfoSource').textContent=`Fuente: ${feature.get('source')}`;
  $('mapInfoSource').href=feature.get('sourceUrl')||'#';
  $('mapInfoUseBase').style.display=kind==='landing'?'inline-flex':'none';
  $('mapInfoAdd').style.display=kind==='landing'?'inline-flex':'inline-flex';
  $('mapInfoAdd').textContent=kind==='landing'?'Agregar este sitio a la misión':'Agregar ubicación a la misión';
  $('mapInfo').dataset.refKind=kind; $('mapInfo').dataset.refId=feature.get('refId');
  box.classList.remove('hide');
}
function closeReferencePopup(){ $('mapInfo')?.classList.add('hide'); }
function addReferenceToMission(feature){
  const point={lat:Number(feature.get('lat')),lon:Number(feature.get('lon')),name:feature.get('name'),type:'target',required:true,dwellMin:15};
  try{validation.points([...missionPoints,point]);}catch(err){showToast(err.message);return;}
  missionPoints.push(point); currentMission=null; selecting=true; drawPointMarkers();renderMissionList();updatePlanningUI();showToast(`${feature.get('name')} se añadió como punto de misión.`);closeReferencePopup();
}
function setBaseFromLanding(feature){
  const base={lat:Number(feature.get('lat')),lon:Number(feature.get('lon')),name:`Base · ${feature.get('name')}`,type:'base',required:true,dwellMin:0,baseSourceId:feature.get('refId')};
  const others=missionPoints.length && missionPoints[0].type==='base' ? missionPoints.slice(1) : missionPoints.filter(p=>p.type!=='base');
  missionPoints=[base,...others]; currentMission=null; selecting=true; routeLayer.getSource().clear(); drawPointMarkers();renderMissionList();resetMetrics();updatePlanningUI();
  map.getView().animate({center:[base.lon,base.lat],zoom:Math.max(map.getView().getZoom(),3),duration:450});
  $('statusText').textContent=`BASE FIJADA · ${feature.get('name')} · agrega los siguientes puntos`;
  showToast(`${feature.get('name')} quedó establecida como BASE (P0).`); closeReferencePopup();
}

function fitCurrentMission(){if(!missionPoints.length){centerGlobal();return;}map.getView().fit(ol.extent.boundingExtent(missionPoints.map(p=>[p.lon,p.lat])),{padding:[70,70,100,70],maxZoom:12.5,duration:400});}
function centerGlobal(){ map.getView().animate({center:[0,0],zoom:1.5,duration:350}); }
function normalizeLon(lon){ let x=((lon+180)%360+360)%360-180; return Math.abs(x)===180?180:x; }
function clampLat(lat){ return clamp(lat,-89.5,89.5); }
function formatLat(lat){ const n=Number(lat); return `${Math.abs(n).toFixed(4)}° ${n<0?'S':'N'}`; }
function formatLon(lon){ const n=normalizeLon(Number(lon)); return `${Math.abs(n).toFixed(4)}° ${n<0?'W':'E'}`; }
function updateMapScale(){
  if(!map || !$('scale')) return;
  const size=map.getSize();
  const resolution=map.getView().getResolution();
  const center=map.getView().getCenter()||[0,0];
  const lat=clamp(Number(center[1])||0,-89,89);
  const widthDeg=Math.min(360,Math.abs((Number(resolution)||0)*(size?.[0]||0)));
  const kmPerDegLon=(Math.PI*MARTIAN_RADIUS/180)*Math.max(.08,Math.cos(lat*Math.PI/180));
  const width=widthDeg*kmPerDegLon;
  $('scale').textContent=Number.isFinite(width) ? `VISTA ~${width>=1000?Math.round(width/100)*100:Math.max(1,Math.round(width))} km` : '—';
}

function onMapClick(evt){
  const hit=map.forEachFeatureAtPixel(evt.pixel,feature=>feature.get('refKind')?feature:null,{hitTolerance:8});
  if(hit){ showReferencePopup(hit); return; }
  if(!selecting) return;
  const [lon,lat]=evt.coordinate;
  if(!Number.isFinite(lon)||!Number.isFinite(lat)) return;
  const index=missionPoints.length;
  const safeLon=normalizeLon(lon); const safeLat=clampLat(lat);
  const point = index===0
    ? {lat:safeLat,lon:safeLon,name:'Base de misión',type:'base',required:true,dwellMin:0}
    : {lat:safeLat,lon:safeLon,name:`Punto ${index}`,type:'target',required:true,dwellMin:15};
  try{validation.points([...missionPoints,point]);}catch(err){showToast(err.message);return;}
  missionPoints.push(point);
  currentMission=null;
  drawPointMarkers(); renderMissionList(); updatePlanningUI();
}
function pointCoordKey(p){ return `${Number(p?.lat).toFixed(5)},${Number(p?.lon).toFixed(5)}`; }
function optimizedVisitIndexMap(){
  const mission=selectedMission?.();
  const seq=mission?.includedPoints||mission?.sequence;
  const out=new Map();
  if(Array.isArray(seq)){
    let n=0;
    seq.forEach((p,i)=>{
      if(i===0||p.type==='base') return;
      const key=pointCoordKey(p);
      if(!out.has(key)) out.set(key,++n);
    });
  }
  return out;
}
function drawPointMarkers(){
  if(!markerLayer) return;
  const source=markerLayer.getSource(); source.clear();
  const visit=optimizedVisitIndexMap();
  const mission=selectedMission?.();
  const seq=mission?.includedPoints||mission?.sequence||[];
  const startKey=seq.length?pointCoordKey(seq[0]):(missionPoints[0]?pointCoordKey(missionPoints[0]):null);
  const endPoint=seq.length?seq[seq.length-1]:null;
  const endKey=endPoint?pointCoordKey(endPoint):null;
  const returnsHome=Boolean(seq.length>1 && startKey && endKey===startKey);
  missionPoints.forEach((p,i)=>{
    const base=p.type==='base'||i===0;
    const key=pointCoordKey(p),visitNo=visit.get(key);
    const isFinish=Boolean(!base && endKey && key===endKey && !returnsHome);
    const label=base?'B':String(visitNo||i);
    source.addFeature(new ol.Feature({
      geometry:new ol.geom.Point([p.lon,p.lat]),
      kind:base?'base':isFinish?'finish':'target',
      label,
      name:p.name||'',
      visit:visitNo||null,
      returnsHome:base&&returnsHome
    }));
  });
  if(!missionPoints.length) source.addFeature(new ol.Feature({geometry:new ol.geom.Point([LANDING.lon,LANDING.lat]),kind:'reference',label:'P'}));
}

function extentKey(ext){ return ext.map(v=>Number(v).toFixed(3)).join(',')+`|${map.getView().getZoom().toFixed(2)}`; }
function rgbaForSlope(v){
  if(!Number.isFinite(v)) return 'rgba(0,0,0,0)';
  const t=clamp(v/18,0,1); const r=Math.round(70+185*t), g=Math.round(210-145*t), b=Math.round(170-110*t);
  return `rgba(${r},${g},${b},0.42)`;
}
function rgbaForRough(v){
  if(!Number.isFinite(v)) return 'rgba(0,0,0,0)';
  const t=clamp(v/220,0,1); const r=Math.round(45+205*t), g=Math.round(190-120*t), b=Math.round(220-170*t);
  return `rgba(${r},${g},${b},0.40)`;
}
function makeGridSamples(ext,cols=15,rows=15){
  const [minX,minY,maxX,maxY]=ext;
  const points=[];
  for(let r=0;r<rows;r++) for(let c=0;c<cols;c++) points.push({lat:minY+(maxY-minY)*r/(rows-1),lon:minX+(maxX-minX)*c/(cols-1)});
  return {points,cols,rows,dx:(maxX-minX)/(cols-1),dy:(maxY-minY)/(rows-1),ext};
}
async function refreshDerivedLayers(force=true){
  if(!map || (!slopeLayer.getVisible() && !roughnessLayer.getVisible())) return;
  const zoom=map.getView().getZoom();
  // A escala planetaria no tiene sentido dibujar una malla analítica densa.
  // Esperamos a un zoom regional para solicitar el DEM y evitamos falsas alarmas.
  if(zoom < 2.2){
    ['slope','roughness'].forEach(n=>{
      const layer=n==='slope'?slopeLayer:roughnessLayer;
      if(layer.getVisible()) setLayerStatus(n,'ACERCA PARA ANALIZAR','ready');
    });
    return;
  }
  const ext=map.getView().calculateExtent(map.getSize());
  const [minX,minY,maxX,maxY]=ext;
  const clipped=[clamp(minX,-179.8),clamp(minY,-89.8),clamp(maxX,179.8),clamp(maxY,89.8)];
  const keyExt=extentKey(clipped);
  if(!force && keyExt===lastDerivedExtentKey) return;
  lastDerivedExtentKey=keyExt;
  const token=++derivedRefreshToken;
  if(slopeLayer.getVisible()) markLayerLoading('slope');
  if(roughnessLayer.getVisible()) markLayerLoading('roughness');
  try{
    const samples=makeGridSamples(clipped,9,9);
    const grid=await getElevations(samples.points);
    if(token!==derivedRefreshToken) return;
    const get=(r,c)=>grid[r*samples.cols+c];
    const slopeFeatures=[], roughFeatures=[];
    for(let r=0;r<samples.rows-1;r++) for(let c=0;c<samples.cols-1;c++){
      const p00=get(r,c),p10=get(r,c+1),p01=get(r+1,c),p11=get(r+1,c+1);
      const vals=[p00?.elevationM,p10?.elevationM,p01?.elevationM,p11?.elevationM].filter(finiteValue).map(Number);
      if(vals.length<4) continue;
      const dxKm=Math.max(.001,haversine(p00,p10));
      const dyKm=Math.max(.001,haversine(p00,p01));
      const sx=Math.atan2(Math.abs((Number(p10.elevationM)-Number(p00.elevationM))/1000),dxKm)*180/Math.PI;
      const sy=Math.atan2(Math.abs((Number(p01.elevationM)-Number(p00.elevationM))/1000),dyKm)*180/Math.PI;
      const slope=Math.max(sx,sy);
      const mean=vals.reduce((a,b)=>a+b,0)/vals.length;
      const rough=Math.sqrt(vals.reduce((a,b)=>a+(b-mean)**2,0)/vals.length);
      const x0=p00.lon,y0=p00.lat,x1=p11.lon,y1=p11.lat;
      const polygon=new ol.geom.Polygon([[[x0,y0],[x1,y0],[x1,y1],[x0,y1],[x0,y0]]]);
      if(slopeLayer.getVisible()) slopeFeatures.push(new ol.Feature({geometry:polygon,slope}));
      if(roughnessLayer.getVisible()) roughFeatures.push(new ol.Feature({geometry:polygon,roughness:rough}));
    }
    slopeLayer.getSource().clear();
    roughnessLayer.getSource().clear();
    slopeFeatures.forEach(f=>f.setStyle(new ol.style.Style({fill:new ol.style.Fill({color:rgbaForSlope(f.get('slope'))}),stroke:new ol.style.Stroke({color:'rgba(255,255,255,.08)',width:1})})));
    roughFeatures.forEach(f=>f.setStyle(new ol.style.Style({fill:new ol.style.Fill({color:rgbaForRough(f.get('roughness'))}),stroke:new ol.style.Stroke({color:'rgba(255,255,255,.08)',width:1})})));
    slopeLayer.getSource().addFeatures(slopeFeatures);
    roughnessLayer.getSource().addFeatures(roughFeatures);
    if(slopeLayer.getVisible()) setLayerStatus('slope',slopeFeatures.length?'ACTIVA':'SIN COBERTURA','live');
    if(roughnessLayer.getVisible()) setLayerStatus('roughness',roughFeatures.length?'ACTIVA':'SIN COBERTURA','live');
  }catch(err){
    if(token!==derivedRefreshToken) return;
    if(slopeLayer.getVisible()) setLayerStatus('slope','NO DISPONIBLE EN ESTA VISTA','ready');
    if(roughnessLayer.getVisible()) setLayerStatus('roughness','NO DISPONIBLE EN ESTA VISTA','ready');
    console.error('Derived layer error',err);
  }
}

const routing=window.JEZERO_ROUTING.createEngine({
  getElevations:points=>getElevations(points),
  optimizeOrderEnabled:()=>$('optimizeOrder')?.checked!==false
});
const {haversine,pathMetrics,nearestNode,neighbors,heuristic,analyzeEdge,edgeCost,aStar,forceEndpoints,shortestLonDelta,interpolateLon,buildGrid,stddev,annotateGridTerrain,gridSizeForDistanceKm,calculateLeg,riskScore,riskLabel,availableMissionHours,estimateDuration,formatHours,formatSignedMargin,sequenceWithReturn,createLegCache,getCachedLeg,evaluateSequence,routeOrderGeodesicCost,heldKarpWaypointOrder,heuristicWaypointOrder,waypointOrderSeed,missionOrderObjective,refineWaypointOrder,chooseSequence,aggregateMission,validateFinalPath}=routing;
async function getElevations(points){
  if(window.JEZERO_DEMO?.enabled)return window.JEZERO_DEMO.sample(points);
  if(!window.marsElevationReady){
    throw new Error('La fuente global de elevación todavía está cargando. Espera unos segundos y vuelve a calcular.');
  }
  await window.marsElevationReady;
  if(typeof window.queryMarsElevations!=='function') throw new Error('La fuente de elevación no está disponible.');
  const out=await window.queryMarsElevations(points);
  if(!Array.isArray(out)) throw new Error('La fuente global de elevación no devolvió puntos.');
  if(out.length!==points.length) throw new Error('La fuente de elevación devolvió una cantidad de muestras inesperada.');
  const valid=out.filter(p=>finiteValue(p.elevationM)).length;
  if(valid===0) throw new Error('El DEM global no devolvió elevaciones válidas para la misión.');
  return out.map(p=>({...p,elevationM:numericValue(p.elevationM)}));
}

function normalizeParams(){
  return validation.parameters(Object.fromEntries(Object.keys(validation.PARAM_RULES).map(id=>[id,$(id)?.value])));
}
function planningFingerprint(){
  return JSON.stringify({points:missionPoints,params:Object.fromEntries(Object.keys(validation.PARAM_RULES).map(id=>[id,$(id)?.value])),returnBase:$('returnBase')?.checked,optimizeOrder:$('optimizeOrder')?.checked});
}
function invalidateMission(){
  currentMission=null;lastCalculatedAt=null;
  routeLayer?.getSource()?.clear();analysisLayer?.getSource()?.clear();
  resetMetrics();updatePlanningUI();
  if($('missionWarnings')){$('missionWarnings').textContent='';$('missionWarnings').hidden=true;}
}
async function calculateMission({saveHistory=true}={}){
  if(missionPoints.length<2||busy)return;
  const fingerprint=planningFingerprint();
  const params=normalizeParams(),returnBase=$('returnBase').checked;
  invalidateMission();
  setBusy(true,ui('Calculando estrategias sobre el mismo terreno…','Calculating strategies on the same terrain…'));
  try{
    const basePoints=validation.points(missionPoints,{minimum:2,calculation:true});
    const legCache=createLegCache(),mission={errors:{}};
    for(const mode of ['distance','balanced','risk']){
      setBusy(true,`${ui('Evaluando estrategia','Evaluating strategy')}: ${strategyLabel(mode)}…`);
      try{mission[mode]=await chooseSequence(mode,basePoints,returnBase,params,legCache);}
      catch(err){mission.errors[mode]=err.message||ui('No se pudo calcular.','Calculation failed.');}
      if(planningFingerprint()!==fingerprint)throw new Error(ui('La misión cambió durante el cálculo. Vuelve a calcular con los datos actuales.','The mission changed during calculation. Recalculate using the current inputs.'));
    }
    currentMission=mission;
    const requested=document.querySelector('input[name="mode"]:checked')?.value||'balanced';
    const selectedMode=[requested,'balanced','distance','risk'].find(mode=>mission[mode]);
    const errors=Object.entries(mission.errors).map(([mode,message])=>`${strategyLabel(mode)}: ${message}`);
    if($('missionWarnings')){$('missionWarnings').textContent=errors.join('\n');$('missionWarnings').hidden=!errors.length;}
    updateStrategyCards(mission);
    if(!selectedMode){currentMission=null;throw new Error(ui('No se pudo calcular ninguna estrategia. Revisa los mensajes y los límites.','No strategy could be calculated. Review the messages and limits.'));}
    lastCalculatedAt=new Date();
    const radio=document.querySelector(`input[name="mode"][value="${selectedMode}"]`);if(radio)radio.checked=true;
    renderMission(mission[selectedMode]);drawMissionRoutes(mission,selectedMode);updatePlanningUI();
    if(saveHistory){
      try{saveHistoryEntry(selectedMode);}
      catch{showToast(ui('Misión calculada, pero no se pudo guardar el historial local. Exporta una copia.','Mission calculated, but local history could not be saved. Export a copy.'));}
    }
    setBusy(false,`${ui('MISIÓN CALCULADA','MISSION CALCULATED')} · ${Object.keys(mission).filter(k=>validation.MODES.includes(k)).length}/3 ${ui('estrategias disponibles','strategies available')}`);
  }catch(err){
    currentMission=null;lastCalculatedAt=null;routeLayer?.getSource()?.clear();
    resetMetrics();updatePlanningUI();
    if($('missionWarnings')){$('missionWarnings').textContent=[$('missionWarnings').textContent,err.message].filter(Boolean).join('\n');$('missionWarnings').hidden=false;}
    setBusy(false,ui('CÁLCULO NO DISPONIBLE · revisa los mensajes','CALCULATION UNAVAILABLE · review the messages'));showToast(err.message);
  }finally{setBusy(false,$('statusText')?.textContent);updateStrategyCards(currentMission);}
}
function drawMissionRoutes(mission,selectedMode){
  const source=routeLayer.getSource(); source.clear();
  const active=mission?.[selectedMode];
  active?.legs?.forEach((leg,index)=>{
    source.addFeature(new ol.Feature({geometry:new ol.geom.LineString(leg.path.map(p=>[p.lon,p.lat])),selected:true,kind:selectedMode,leg:index+1}));
  });
  drawPointMarkers();
}

function selectedMission(){
  const mode=document.querySelector('input[name="mode"]:checked')?.value||'balanced';
  return currentMission?.[mode]||null;
}
function missionPathNodes(mission){
  const out=[];
  (mission?.legs||[]).forEach((leg,li)=>{
    (leg.path||[]).forEach((node,ni)=>{
      if(li>0 && ni===0) return;
      out.push(node);
    });
  });
  return out;
}
function profileSeries(mission){
  const nodes=missionPathNodes(mission);
  const series=[];
  let km=0,prev=null;
  for(const node of nodes){
    if(prev) km+=haversine(prev,node);
    if(finiteValue(node.elevationM)) series.push({km,elevationM:Number(node.elevationM)});
    prev=node;
  }
  return series;
}
function renderTerrainProfile(mission){
  const host=$('terrainProfileMini'); if(!host) return;
  const pts=profileSeries(mission);
  if(pts.length<2){host.innerHTML=`<span>${ui('Calcula una misión para generar el perfil.','Calculate a mission to generate the profile.')}</span>`;return;}
  const minE=Math.min(...pts.map(x=>x.elevationM)),maxE=Math.max(...pts.map(x=>x.elevationM));
  const span=Math.max(1,maxE-minE),maxKm=Math.max(.001,pts.at(-1).km);
  const W=520,H=150,padX=30,padY=18,plotW=W-padX*2,plotH=H-padY*2;
  const coords=pts.map(p=>`${(padX+p.km/maxKm*plotW).toFixed(1)},${(padY+(maxE-p.elevationM)/span*plotH).toFixed(1)}`).join(' ');
  const fill=`${padX},${H-padY} ${coords} ${W-padX},${H-padY}`;
  const c=themeColors();
  host.innerHTML=`<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${ui('Perfil de elevación de la ruta','Route elevation profile')}">
    <defs><linearGradient id="jezeroProfileFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${c.accent2}" stop-opacity=".42"/><stop offset="1" stop-color="${c.accent2}" stop-opacity=".04"/></linearGradient></defs>
    <line x1="${padX}" y1="${padY}" x2="${padX}" y2="${H-padY}" class="profileAxis"/>
    <line x1="${padX}" y1="${H-padY}" x2="${W-padX}" y2="${H-padY}" class="profileAxis"/>
    <polygon points="${fill}" fill="url(#jezeroProfileFill)"/>
    <polyline points="${coords}" fill="none" stroke="${c.accent}" stroke-width="3" vector-effect="non-scaling-stroke"/>
    <text x="${padX}" y="12">${Math.round(maxE)} m</text>
    <text x="${padX}" y="${H-3}">${Math.round(minE)} m</text>
    <text x="${W-padX}" y="${H-3}" text-anchor="end">${maxKm.toFixed(2)} km</text>
  </svg>`;
}

let analyticsPinnedPoint=null;
function analyticsSeries(mission){
  if(!mission?.legs?.length) return [];
  const out=[]; let km=0,elapsed=0,gain=0,descent=0,prevGlobal=null;
  const params=mission.params||normalizeParams();
  mission.legs.forEach((leg,li)=>{
    const path=leg.path||[]; if(!path.length) return;
    let legDist=0; for(let i=1;i<path.length;i++) legDist+=haversine(path[i-1],path[i]);
    for(let i=0;i<path.length;i++){
    const node=path[i];
      if(li>0&&i===0) continue;
      let edge=0;
      if(prevGlobal){
        edge=haversine(prevGlobal,node); km+=edge;
        if(finiteValue(prevGlobal.elevationM)&&finiteValue(node.elevationM)){
          const de=Number(node.elevationM)-Number(prevGlobal.elevationM); if(de>0) gain+=de; else descent+=Math.abs(de);
        }
        if(legDist>0) elapsed+=(Number(leg.durationHours)||0)*(edge/legDist);
      }
      const slope=finiteValue(node.signedSlopeDeg)?Number(node.signedSlopeDeg):finiteValue(node.slopeDeg)?Number(node.slopeDeg):null;
      const transit=finiteValue(node.transitability)?Number(node.transitability):finiteValue(node.baseTransitability)?Number(node.baseTransitability):null;
      const confidence=finiteValue(node.edgeConfidence)?Number(node.edgeConfidence):finiteValue(node.dataConfidence)?Number(node.dataConfidence):null;
      const roughness=finiteValue(node.localRoughnessDeg)?Number(node.localRoughnessDeg):null;
      const difficulty=clamp((Math.abs(slope||0)/25)*35 + ((100-(transit??100))/100)*30 + ((100-(confidence??100))/100)*20 + ((roughness||0)/10)*15,0,100);
      out.push({km,lat:Number(node.lat),lon:Number(node.lon),elevationM:finiteValue(node.elevationM)?Number(node.elevationM):null,slope,transit,confidence,roughness,difficulty,cumGain:gain,cumDescent:descent,elapsedHours:elapsed,evaRemaining:availableMissionHours(params)-elapsed});
      prevGlobal=node;
    }
    const dwell=(Number(leg.to?.dwellMin)||0)/60;
    if(dwell>0&&out.length){elapsed+=dwell;out[out.length-1].elapsedHours=elapsed;out[out.length-1].evaRemaining=availableMissionHours(params)-elapsed;}
  });
  return out;
}
function analyticsDistanceBins(series,key,classify,labels){
  const values=Object.fromEntries(labels.map(x=>[x,0])); let total=0;
  for(let i=1;i<series.length;i++){
    const dist=Math.max(0,series[i].km-series[i-1].km),value=series[i][key];
    if(!Number.isFinite(dist)||dist<=0||!Number.isFinite(value)) continue;
    const label=classify(value); if(label in values){values[label]+=dist;total+=dist;}
  }
  return labels.map(label=>({label,km:values[label],pct:total?values[label]/total*100:0}));
}
function clearAnalyticsMapHighlight(){analysisLayer?.getSource()?.clear();}
function updateAnalyticsMiniCursor(point){
  const dot=$('analyticsMiniCursor'); if(!dot||!point) return;
  const host=$('analyticsMiniMap'),svg=host?.querySelector('svg'); if(!svg) return;
  const minLon=Number(svg.dataset.minLon),maxLon=Number(svg.dataset.maxLon),minLat=Number(svg.dataset.minLat),maxLat=Number(svg.dataset.maxLat);
  const W=480,H=180,L=20,R=20,T=18,B=18;
  const x=L+(point.lon-minLon)/Math.max(1e-9,maxLon-minLon)*(W-L-R),y=T+(maxLat-point.lat)/Math.max(1e-9,maxLat-minLat)*(H-T-B);
  dot.setAttribute('cx',x);dot.setAttribute('cy',y);dot.setAttribute('visibility','visible');
}
function syncAnalyticsCursor(point,{pin=false,highlightMap=true}={}){
  if(!point) return;
  if(pin) analyticsPinnedPoint=point;
  document.querySelectorAll('svg[data-sync-chart]').forEach(svg=>{
    const maxKm=Number(svg.dataset.maxKm)||1,W=Number(svg.dataset.w)||480,L=Number(svg.dataset.l)||48,R=Number(svg.dataset.r)||16;
    const x=L+clamp(point.km/maxKm,0,1)*(W-L-R); const line=svg.querySelector('.analyticsSyncCursor');
    if(line){line.setAttribute('x1',x);line.setAttribute('x2',x);line.setAttribute('visibility','visible');}
  });
  if($('analyticsSelectionReadout')) $('analyticsSelectionReadout').textContent=`KM ${point.km.toFixed(2)} · ${formatLat(point.lat)} · ${formatLon(point.lon)} · pendiente ${Number.isFinite(point.slope)?point.slope.toFixed(1)+'°':'—'} · transit. ${Number.isFinite(point.transit)?Math.round(point.transit)+'/100':'—'} · calidad de muestreo ${Number.isFinite(point.confidence)?Math.round(point.confidence)+'%':'—'}`;
  updateAnalyticsMiniCursor(point);
  if(highlightMap&&analysisLayer){
    const src=analysisLayer.getSource();src.clear();src.addFeature(new ol.Feature({geometry:new ol.geom.Point([point.lon,point.lat]),analysisKind:'point',label:`${point.km.toFixed(2)} km`}));
  }
}
function clearAnalyticsSelection(){
  analyticsPinnedPoint=null; clearAnalyticsMapHighlight();
  document.querySelectorAll('.analyticsSyncCursor').forEach(line=>line.setAttribute('visibility','hidden'));
  const dot=$('analyticsMiniCursor');if(dot)dot.setAttribute('visibility','hidden');
  if($('analyticsSelectionReadout')) $('analyticsSelectionReadout').textContent=ui('Mueve el cursor sobre un gráfico para inspeccionar la ruta.','Move the cursor over a chart to inspect the route.');
}
function bindSyncedChart(host,svg,series,{tooltip=null}={}){
  if(!host||!svg||series.length<2) return;
  const W=Number(svg.dataset.w)||480,L=Number(svg.dataset.l)||48,R=Number(svg.dataset.r)||16,maxKm=Number(svg.dataset.maxKm)||series.at(-1).km||1;
  const pick=e=>{
    const rect=svg.getBoundingClientRect(),left=rect.left+rect.width*(L/W),right=rect.right-rect.width*(R/W),frac=clamp((e.clientX-left)/Math.max(1,right-left),0,1),target=frac*maxKm;
    let best=series[0];for(const p of series)if(Math.abs(p.km-target)<Math.abs(best.km-target))best=p;
    syncAnalyticsCursor(best,{pin:false});
    if(tooltip){tooltip.hidden=false;tooltip.style.left=`${Math.min(host.clientWidth-230,Math.max(8,e.clientX-host.getBoundingClientRect().left+12))}px`;tooltip.style.top='44px';tooltip.innerHTML=`<b>${best.km.toFixed(2)} km</b><br>${ui('Elevación','Elevation')}: ${Number.isFinite(best.elevationM)?Math.round(best.elevationM)+' m':'—'}<br>${ui('Pendiente','Slope')}: ${Number.isFinite(best.slope)?best.slope.toFixed(1)+'°':'—'}<br>${ui('Rugosidad','Roughness')}: ${Number.isFinite(best.roughness)?best.roughness.toFixed(1)+'°':'—'}<br>${ui('Transitabilidad','Traversability')}: ${Number.isFinite(best.transit)?Math.round(best.transit)+'/100':'—'}<br>${ui('Calidad de muestreo','Sampling quality')}: ${Number.isFinite(best.confidence)?Math.round(best.confidence)+'%':'—'}`;}
    return best;
  };
  svg.addEventListener('pointermove',pick);
  svg.addEventListener('click',e=>{const best=pick(e);syncAnalyticsCursor(best,{pin:true});});
  svg.addEventListener('pointerleave',()=>{if(tooltip)tooltip.hidden=true;if(analyticsPinnedPoint)syncAnalyticsCursor(analyticsPinnedPoint);else clearAnalyticsSelection();});
}
function v36BarRows(host,rows,{series=null,key=null,classify=null}={}){
  host.innerHTML=`<div class="v36Bars">${rows.map(r=>`<div class="v36BarRow" tabindex="0" data-bin="${escapeHtml(r.label)}"><span>${escapeHtml(r.label)}</span><div class="v36BarTrack"><div class="v36BarFill" style="width:${clamp(Number(r.pct)||0,0,100).toFixed(1)}%"></div></div><strong>${Number(r.pct||0).toFixed(0)}%</strong><em>${Number(r.km||0).toFixed(2)} km</em></div>`).join('')}</div>`;
  host.querySelectorAll('[data-bin]').forEach(row=>{
    const label=row.dataset.bin,activate=()=>{
      const r=rows.find(x=>x.label===label);if($('analyticsSelectionReadout'))$('analyticsSelectionReadout').textContent=`${label} · ${r?.km.toFixed(2)||'0.00'} km · ${r?.pct.toFixed(1)||'0.0'}% de la ruta`;
      if(series&&key&&classify&&analysisLayer){const src=analysisLayer.getSource();src.clear();for(let i=1;i<series.length;i++){if(classify(series[i][key])!==label)continue;src.addFeature(new ol.Feature({geometry:new ol.geom.LineString([[series[i-1].lon,series[i-1].lat],[series[i].lon,series[i].lat]]),analysisKind:'segment'}));}}
    };
    row.addEventListener('pointerenter',activate);row.addEventListener('focus',activate);row.addEventListener('click',activate);row.addEventListener('pointerleave',()=>{if(analyticsPinnedPoint)syncAnalyticsCursor(analyticsPinnedPoint);else clearAnalyticsMapHighlight();});
  });
}
function renderAnalyticsProfile(mission){
  const host=$('analyticsProfileChart');if(!host)return;const series=analyticsSeries(mission);
  if(series.length<2){host.innerHTML=`<div class="chartEmpty">${ui('Calcula una misión para generar el perfil multicapa.','Calculate a mission to generate the multi-layer profile.')}</div>`;return;}
  const c=themeColors(),W=980,H=380,L=78,R=20,T=16,B=26,maxKm=Math.max(.001,series.at(-1).km);
  const elev=series.filter(p=>Number.isFinite(p.elevationM)),minE=Math.min(...elev.map(p=>p.elevationM)),maxE=Math.max(...elev.map(p=>p.elevationM)),spanE=Math.max(1,maxE-minE),maxSlope=Math.max(15,mission?.metrics?.maxSlopeDeg||15),maxRough=Math.max(5,...series.map(p=>p.roughness||0));
  const tracks=[
    {key:'elevationM',label:ui('ELEVACIÓN','ELEVATION'),top:20,h:78,min:minE,max:maxE,color:c.accent},
    {key:'slope',label:ui('PENDIENTE','SLOPE'),top:112,h:48,min:-maxSlope,max:maxSlope,color:c.warning},
    {key:'roughness',label:ui('RUGOSIDAD','ROUGHNESS'),top:176,h:42,min:0,max:maxRough,color:c.primary2},
    {key:'transit',label:ui('TRANSIT.','TRAV.'),top:234,h:42,min:0,max:100,color:c.success},
    {key:'confidence',label:ui('CALIDAD','CONFIDENCE'),top:292,h:42,min:0,max:100,color:c.accent2}
  ];
  const x=p=>L+p.km/maxKm*(W-L-R),y=(v,t)=>t.top+t.h-(v-t.min)/Math.max(.001,t.max-t.min)*t.h;
  let svg=`<svg viewBox="0 0 ${W} ${H}" data-sync-chart data-w="${W}" data-l="${L}" data-r="${R}" data-max-km="${maxKm}">`;
  for(let g=0;g<=5;g++){const gx=L+(W-L-R)*g/5;svg+=`<line class="chartGrid" x1="${gx}" y1="${T}" x2="${gx}" y2="${H-B}"/><text class="chartLabel" x="${gx}" y="${H-7}" text-anchor="middle">${(maxKm*g/5).toFixed(1)} km</text>`;}
  tracks.forEach(t=>{svg+=`<text class="chartTitle" x="8" y="${t.top+10}">${t.label}</text><line class="chartAxis" x1="${L}" y1="${t.top+t.h}" x2="${W-R}" y2="${t.top+t.h}"/>`;const pts=series.filter(p=>Number.isFinite(p[t.key])).map(p=>`${x(p).toFixed(1)},${y(p[t.key],t).toFixed(1)}`).join(' ');if(pts)svg+=`<polyline points="${pts}" fill="none" stroke="${t.color}" stroke-width="2.4" vector-effect="non-scaling-stroke"/>`;});
  svg+=`<line class="chartCursor analyticsSyncCursor" x1="${L}" x2="${L}" y1="${T}" y2="${H-B}" visibility="hidden"/><rect class="chartHit" x="${L}" y="${T}" width="${W-L-R}" height="${H-T-B}"/></svg>`;host.innerHTML=svg;bindSyncedChart(host,host.querySelector('svg'),series,{tooltip:$('analyticsProfileTooltip')});
}
function renderAnalyticsDistributions(mission){
  const s=analyticsSeries(mission);if(s.length<2){['analyticsSlopeChart','analyticsTransitChart','analyticsRoughnessChart','analyticsConfidenceChart'].forEach(id=>{if($(id))$(id).innerHTML='<div class="chartEmpty">Sin datos.</div>';});return;}
  const slopeClass=v=>{v=Math.abs(v);return v<5?'0–5°':v<10?'5–10°':v<15?'10–15°':'>15°';},slopeLabels=['0–5°','5–10°','10–15°','>15°'];
  const transitClass=v=>v>=80?ui('Segura','Safe'):v>=60?ui('Moderada','Moderate'):v>=40?ui('Difícil','Difficult'):ui('Crítica','Critical'),transitLabels=[ui('Segura','Safe'),ui('Moderada','Moderate'),ui('Difícil','Difficult'),ui('Crítica','Critical')];
  const roughClass=v=>v<1.5?ui('Baja','Low'):v<3?ui('Media','Medium'):v<6?ui('Alta','High'):ui('Muy alta','Very high'),roughLabels=[ui('Baja','Low'),ui('Media','Medium'),ui('Alta','High'),ui('Muy alta','Very high')];
  const confClass=v=>v>=90?'90–100%':v>=75?'75–90%':v>=50?'50–75%':'<50%',confLabels=['90–100%','75–90%','50–75%','<50%'];
  v36BarRows($('analyticsSlopeChart'),analyticsDistanceBins(s,'slope',slopeClass,slopeLabels),{series:s,key:'slope',classify:slopeClass});
  v36BarRows($('analyticsTransitChart'),analyticsDistanceBins(s,'transit',transitClass,transitLabels),{series:s,key:'transit',classify:transitClass});
  v36BarRows($('analyticsRoughnessChart'),analyticsDistanceBins(s,'roughness',roughClass,roughLabels),{series:s,key:'roughness',classify:roughClass});
  v36BarRows($('analyticsConfidenceChart'),analyticsDistanceBins(s,'confidence',confClass,confLabels),{series:s,key:'confidence',classify:confClass});
}
function renderAnalyticsEva(mission){
  const host=$('analyticsEvaChart');if(!host)return;if(!mission){host.innerHTML='<div class="chartEmpty">Sin datos.</div>';return;}
  const available=mission.availableHours??availableMissionHours(mission.params||normalizeParams()),dwell=Math.max(0,(Number(mission.dwellMinutes)||0)/60),travel=Math.max(0,(Number(mission.duration)||0)-dwell),reserve=Math.max(0,available-Number(mission.duration||0)),exceed=Math.max(0,Number(mission.duration||0)-available),total=Math.max(.001,travel+dwell+reserve+exceed);
  const parts=[{label:ui('TRÁNSITO','TRAVEL'),v:travel,bg:'var(--theme-primary-2)'},{label:ui('PARADAS','STOPS'),v:dwell,bg:'var(--theme-accent)'},{label:ui('RESERVA','RESERVE'),v:reserve,bg:'var(--theme-success)'},{label:ui('EXCESO','OVERRUN'),v:exceed,bg:'var(--theme-danger)'}].filter(x=>x.v>.0001);
  host.innerHTML=`<div class="v35EvaBudget">${parts.map(x=>`<span class="evaBudgetPart" tabindex="0" style="width:${x.v/total*100}%;background:${x.bg}" data-label="${x.label}" data-hours="${x.v}">${x.v/total*100>13?Math.round(x.v/total*100)+'%':''}</span>`).join('')}</div><div class="v35EvaLegend">${parts.map(x=>`<div><span>${x.label}</span><b>${formatHours(x.v)}</b></div>`).join('')}</div>`;
  host.querySelectorAll('.evaBudgetPart').forEach(el=>{const show=()=>{$('analyticsSelectionReadout').textContent=`${el.dataset.label} · ${formatHours(Number(el.dataset.hours))}`;};el.addEventListener('pointerenter',show);el.addEventListener('focus',show);});
}
function renderSyncedLineChart(hostId,mission,defs,{zero=false}={}){
  const host=$(hostId);if(!host)return;const s=analyticsSeries(mission);if(s.length<2){host.innerHTML='<div class="chartEmpty">Sin datos.</div>';return;}
  const W=480,H=180,L=48,R=16,T=16,B=28,maxKm=Math.max(.001,s.at(-1).km),colors=themeColors(),palette=[colors.accent2,colors.warning,colors.success,colors.accent,colors.primary2];
  const values=defs.flatMap(d=>s.map(p=>p[d.key]).filter(Number.isFinite));let min=Math.min(...values),max=Math.max(...values);if(zero){min=Math.min(0,min);max=Math.max(0,max);}if(Math.abs(max-min)<1e-9){max+=1;min-=1;}
  const x=p=>L+p.km/maxKm*(W-L-R),y=v=>T+(max-v)/(max-min)*(H-T-B);let svg=`<svg viewBox="0 0 ${W} ${H}" data-sync-chart data-w="${W}" data-l="${L}" data-r="${R}" data-max-km="${maxKm}">`;
  for(let g=0;g<=4;g++){const gx=L+(W-L-R)*g/4;svg+=`<line class="chartGrid" x1="${gx}" y1="${T}" x2="${gx}" y2="${H-B}"/><text class="chartLabel" x="${gx}" y="${H-7}" text-anchor="middle">${(maxKm*g/4).toFixed(1)}</text>`;}
  if(zero&&min<0&&max>0){const yz=y(0);svg+=`<line x1="${L}" x2="${W-R}" y1="${yz}" y2="${yz}" stroke="${colors.danger}" stroke-dasharray="4 3"/>`;}
  defs.forEach((d,i)=>{const pts=s.filter(p=>Number.isFinite(p[d.key])).map(p=>`${x(p).toFixed(1)},${y(p[d.key]).toFixed(1)}`).join(' ');svg+=`<polyline points="${pts}" fill="none" stroke="${d.color||palette[i%palette.length]}" stroke-width="2.5"/><text class="chartTitle" x="${L+5}" y="${T+11+i*13}" fill="${d.color||palette[i%palette.length]}">${d.label}</text>`;});
  svg+=`<line class="chartCursor analyticsSyncCursor" x1="${L}" x2="${L}" y1="${T}" y2="${H-B}" visibility="hidden"/><rect class="chartHit" x="${L}" y="${T}" width="${W-L-R}" height="${H-T-B}"/></svg>`;host.innerHTML=svg;bindSyncedChart(host,host.querySelector('svg'),s);
}
function renderAnalyticsReturn(mission){renderSyncedLineChart('analyticsReturnChart',mission,[{key:'evaRemaining',label:ui('VENTANA EVA RESTANTE (h)','REMAINING EVA WINDOW (h)')}],{zero:true});}
function renderAnalyticsGain(mission){renderSyncedLineChart('analyticsElevationGainChart',mission,[{key:'cumGain',label:ui('ASCENSO ACUM. (m)','CUM. ASCENT (m)')},{key:'cumDescent',label:ui('DESCENSO ACUM. (m)','CUM. DESCENT (m)')}]);}
function renderAnalyticsExposure(mission){renderSyncedLineChart('analyticsExposureChart',mission,[{key:'difficulty',label:ui('DIFICULTAD /100','DIFFICULTY /100')}]);}
function activateStrategyFromAnalytics(mode){
  const radio=document.querySelector(`input[name="mode"][value="${mode}"]`);if(!radio||!currentMission?.[mode])return;radio.checked=true;renderMission(currentMission[mode]);drawMissionRoutes(currentMission,mode);drawPointMarkers();if($('analyticsStrategySelect'))$('analyticsStrategySelect').value=mode;
}
function renderAnalyticsRoutes(selected){
  const host=$('analyticsRoutesChart');if(!host)return;const rows=['distance','balanced','risk'].map(k=>currentMission?.[k]).filter(Boolean);if(!rows.length){host.innerHTML='<div class="chartEmpty">Calcula la misión para comparar estrategias.</div>';return;}
  const label=m=>m.mode==='distance'?ui('MÁS DIRECTA','MOST DIRECT'):m.mode==='risk'?ui('MENOR EXPOSICIÓN','LOWER EXPOSURE'):ui('EQUILIBRADA','BALANCED');
  const metrics=[[ui('Distancia','Distance'),m=>`${m.metrics.distanceKm.toFixed(2)} km`],[ui('Duración','Duration'),m=>formatHours(m.duration)],[ui('Pendiente máx.','Max slope'),m=>`${m.metrics.maxSlopeDeg?.toFixed(1)??'—'}°`],[ui('Transitabilidad','Traversability'),m=>`${Math.round(m.metrics.avgTransitability??0)}/100`],[ui('Calidad de muestreo','Sampling quality'),m=>`${Math.round(m.metrics.avgConfidence??0)}%`],[ui('Dificultad','Difficulty'),m=>`${m.score??'—'}/100`],[ui('Orden','Order'),m=>(m.orderOptimization?.optimizedOrder||[]).map((name,i)=>`${i+1}:${name}`).join(' → ')||'—']];
  host.innerHTML=`<div class="v36RouteCompare"><div class="head">${ui('MÉTRICA','METRIC')}</div>${rows.map(m=>`<button class="head strategyPick ${m.mode===selected?.mode?'selected':''}" data-strategy="${m.mode}">${label(m)}</button>`).join('')}${metrics.map(([name,fn])=>`<div class="metric">${name}</div>${rows.map(m=>`<button class="value strategyPick ${m.mode===selected?.mode?'selected':''}" data-strategy="${m.mode}">${escapeHtml(fn(m))}</button>`).join('')}`).join('')}</div>`;
  host.querySelectorAll('[data-strategy]').forEach(btn=>btn.addEventListener('click',()=>activateStrategyFromAnalytics(btn.dataset.strategy)));
}
function renderAnalyticsHealth(mission){
  const host=$('analyticsHealthChart');if(!host)return;if(!mission){host.innerHTML='<div class="chartEmpty">Sin datos.</div>';return;}
  const available=mission.availableHours??availableMissionHours(mission.params||normalizeParams()),margin=available-Number(mission.duration||0),m=mission.metrics||{};
  const vals=[[ui('Transitabilidad media','Average traversability'),clamp(Number(m.avgTransitability)||0,0,100)],[ui('Calidad de muestreo','Sampling quality'),clamp(Number(m.avgConfidence)||0,0,100)],[ui('Condición del terreno','Terrain condition'),clamp(100-(Number(mission.score)||0),0,100)],[ui('Margen EVA','EVA margin'),margin<=0?0:clamp(margin/Math.max(.001,available)*100,0,100)],[ui('Cobertura de datos','Data coverage'),clamp(100-(Number(m.uncertainDistanceKm)||0)/Math.max(.001,Number(m.distanceKm)||1)*100,0,100)],[ui('Viabilidad temporal','Time feasibility'),mission.overBudget?0:100]];
  host.innerHTML=`<div class="v35Health">${vals.map(([name,v])=>`<div class="v35HealthItem" tabindex="0"><span>${name}</span><div class="v35HealthTrack"><div class="v35HealthFill" style="width:${v.toFixed(1)}%"></div></div><b>${Math.round(v)}</b></div>`).join('')}</div>`;
  host.querySelectorAll('.v35HealthItem').forEach(el=>el.addEventListener('pointerenter',()=>{$('analyticsSelectionReadout').textContent=`${el.querySelector('span').textContent} · ${el.querySelector('b').textContent}/100`;}));
}
function renderAnalyticsMiniMap(mission){
  const host=$('analyticsMiniMap');if(!host)return;const s=analyticsSeries(mission);if(s.length<2){host.innerHTML='<div class="chartEmpty">Sin datos.</div>';return;}
  const W=480,H=180,L=20,R=20,T=18,B=18,minLon=Math.min(...s.map(p=>p.lon)),maxLon=Math.max(...s.map(p=>p.lon)),minLat=Math.min(...s.map(p=>p.lat)),maxLat=Math.max(...s.map(p=>p.lat)),spanLon=Math.max(.001,maxLon-minLon),spanLat=Math.max(.001,maxLat-minLat),x=p=>L+(p.lon-minLon)/spanLon*(W-L-R),y=p=>T+(maxLat-p.lat)/spanLat*(H-T-B),coords=s.map(p=>`${x(p).toFixed(1)},${y(p).toFixed(1)}`).join(' '),c=themeColors();
  host.innerHTML=`<svg viewBox="0 0 ${W} ${H}" data-min-lon="${minLon}" data-max-lon="${maxLon}" data-min-lat="${minLat}" data-max-lat="${maxLat}"><rect x="${L}" y="${T}" width="${W-L-R}" height="${H-T-B}" fill="none" class="chartAxis"/><polyline points="${coords}" fill="none" stroke="${c.accent}" stroke-width="4"/><circle cx="${x(s[0])}" cy="${y(s[0])}" r="5" fill="${c.success}"/><circle id="analyticsMiniCursor" cx="${x(s[0])}" cy="${y(s[0])}" r="6" fill="${c.warning}" stroke="${c.bg}" stroke-width="2" visibility="hidden"/><rect class="chartHit" x="${L}" y="${T}" width="${W-L-R}" height="${H-T-B}"/></svg>`;
  const svg=host.querySelector('svg');
  const pick=e=>{const r=svg.getBoundingClientRect(),px=(e.clientX-r.left)/Math.max(1,r.width)*W,py=(e.clientY-r.top)/Math.max(1,r.height)*H;let best=s[0],bestD=Infinity;for(const q of s){const dx=x(q)-px,dy=y(q)-py,d=dx*dx+dy*dy;if(d<bestD){bestD=d;best=q;}}syncAnalyticsCursor(best,{pin:false});return best;};
  svg.addEventListener('pointermove',pick);svg.addEventListener('click',e=>syncAnalyticsCursor(pick(e),{pin:true}));svg.addEventListener('pointerleave',()=>{if(analyticsPinnedPoint)syncAnalyticsCursor(analyticsPinnedPoint);else clearAnalyticsSelection();});
  if(analyticsPinnedPoint)updateAnalyticsMiniCursor(analyticsPinnedPoint);
}
function renderAnalyticsSegments(mission){
  const host=$('analyticsSegmentsTable');if(!host)return;if(!mission?.legs?.length){host.innerHTML='<div class="chartEmpty">Sin datos.</div>';return;}
  host.innerHTML=`<table class="v36SegmentTable"><thead><tr><th>#</th><th>TRAMO</th><th>KM</th><th>TIEMPO</th><th>PEND. MÁX.</th><th>TRANSIT.</th><th>CALIDAD</th><th>DIFICULTAD</th></tr></thead><tbody>${mission.legs.map((leg,i)=>`<tr tabindex="0" data-leg="${i}"><td>${i+1}</td><td>${escapeHtml(leg.from?.name||'—')} → ${escapeHtml(leg.to?.name||'—')}</td><td>${Number(leg.metrics?.distanceKm||0).toFixed(2)}</td><td>${formatHours(leg.durationHours)}</td><td>${Number(leg.metrics?.maxSlopeDeg||0).toFixed(1)}°</td><td>${Math.round(leg.metrics?.avgTransitability??0)}</td><td>${Math.round(leg.metrics?.avgConfidence??0)}%</td><td>${riskScore(leg.metrics)??'—'}</td></tr>`).join('')}</tbody></table>`;
  host.querySelectorAll('[data-leg]').forEach(row=>{const activate=()=>{const leg=mission.legs[Number(row.dataset.leg)];if(!leg)return;const src=analysisLayer?.getSource();src?.clear();src?.addFeature(new ol.Feature({geometry:new ol.geom.LineString((leg.path||[]).map(p=>[p.lon,p.lat])),analysisKind:'segment'}));$('analyticsSelectionReadout').textContent=`TRAMO ${Number(row.dataset.leg)+1} · ${leg.from?.name||'—'} → ${leg.to?.name||'—'} · ${Number(leg.metrics?.distanceKm||0).toFixed(2)} km`;};row.addEventListener('pointerenter',activate);row.addEventListener('focus',activate);row.addEventListener('click',activate);});
}
function renderMissionAnalytics(mission){
  if($('analyticsRouteName'))$('analyticsRouteName').textContent=mission?($('routeName')?.textContent||ui('RUTA ACTIVA','ACTIVE ROUTE')):ui('SIN MISIÓN','NO MISSION');
  if($('analyticsGeneratedAt'))$('analyticsGeneratedAt').textContent=mission&&lastCalculatedAt?lastCalculatedAt.toLocaleString(uiLang()==='en'?'en-US':'es-NI',{dateStyle:'short',timeStyle:'short'}):ui('CALCULA UNA RUTA','CALCULATE A ROUTE');
  if($('analyticsStrategySelect')){
    if(mission)$('analyticsStrategySelect').value=mission.mode;
    [...$('analyticsStrategySelect').options].forEach(option=>option.disabled=Boolean(currentMission?.errors?.[option.value]));
  }
  renderAnalyticsProfile(mission);renderAnalyticsDistributions(mission);renderAnalyticsEva(mission);renderAnalyticsReturn(mission);renderAnalyticsGain(mission);renderAnalyticsExposure(mission);renderAnalyticsRoutes(mission);renderAnalyticsHealth(mission);renderAnalyticsMiniMap(mission);renderAnalyticsSegments(mission);
  if(analyticsPinnedPoint)syncAnalyticsCursor(analyticsPinnedPoint);
}

function updateRouteSequenceStrip(mission){
  const strip=$('routeSequenceStrip'),flow=$('routeSequenceFlow');if(!strip||!flow)return;
  const seq=mission?.includedPoints||mission?.sequence||[];
  if(!mission||seq.length<2){strip.classList.add('is-empty');flow.innerHTML='';return;}
  strip.classList.remove('is-empty');
  let visit=0;
  const startKey=pointCoordKey(seq[0]);
  const parts=seq.map((p,i)=>{
    const isBase=p.type==='base'||i===0;
    const isHome=i===seq.length-1&&i>0&&pointCoordKey(p)===startKey;
    const code=isBase?(isHome?'HOME':'BASE'):String(++visit).padStart(2,'0');
    const cls=isHome?'home':isBase?'base':'point';
    return `<b class="${cls}" title="${escapeHtml(p.name||code)}">${code}</b>`;
  });
  flow.innerHTML=parts.join('<i>→</i>');
}

function renderMissionTimeline(mission){
  const host=$('missionTimeline');if(!host)return;
  const seq=mission?.includedPoints||mission?.sequence||missionPoints;
  if(!seq?.length){host.innerHTML='<div class="timelineEmpty"><b>Tu recorrido aparecerá aquí</b><p>Añade una base y un destino. Al calcular verás las paradas y el regreso.</p></div>';return;}
  let visit=0;
  host.innerHTML=seq.map((p,i)=>{
    const base=p.type==='base'||i===0,home=base&&i===seq.length-1&&i>0;
    const code=base?(home?'HOME':'BASE'):`${String(++visit).padStart(2,'0')}`;
    return `<div class="timelineNode ${base?'base':'required'}"><span>${code}</span><b>${escapeHtml(p.name||code)}</b></div>${i<seq.length-1?'<i class="timelineLink"></i>':''}`;
  }).join('');
}

function updateMissionHud(mission){
  const m=mission?.metrics||{},available=mission?.availableHours ?? (mission?.params?availableMissionHours(mission.params):null),margin=Number.isFinite(available)&&Number.isFinite(mission?.duration)?available-mission.duration:null;
  if($('hudPlan'))$('hudPlan').textContent=mission?ui('RUTA ACTIVA','ACTIVE ROUTE'):ui('SIN RUTA','NO ROUTE');
  if($('hudDistance'))$('hudDistance').textContent=Number.isFinite(m.distanceKm)?`${m.distanceKm.toFixed(2)} km`:'—';
  if($('hudTransit'))$('hudTransit').textContent=Number.isFinite(m.avgTransitability)?`${Math.round(m.avgTransitability)}/100`:'—';
  if($('hudReturn'))$('hudReturn').textContent=Number.isFinite(margin)?formatSignedMargin(margin):'—';
}

function updateHeaderStatus(){
  const meta=getMissionSettings?.()||{};
  if($('headerMissionCode'))$('headerMissionCode').textContent=meta.missionCode||meta.missionName||ui('SIN ID','NO ID');
  if($('headerTargetCount'))$('headerTargetCount').textContent=String(Math.max(0,missionPoints.filter((p,i)=>i>0&&p.type!=='base').length));
}

function strategyLabel(mode){
  return mode==='distance'?ui('Más directa','Most direct'):mode==='risk'?ui('Menor exposición','Lower exposure'):ui('Equilibrada','Balanced');
}
function strategySummary(mission){
  if(!mission?.metrics) return ui('Calcula para comparar','Calculate to compare');
  const m=mission.metrics;
  const dist=Number.isFinite(m.distanceKm)?`${m.distanceKm.toFixed(2)} km`:'—';
  const slope=Number.isFinite(m.maxSlopeDeg)?`${m.maxSlopeDeg.toFixed(1)}°`:'—';
  const trv=Number.isFinite(m.avgTransitability)?`TRV ${Math.round(m.avgTransitability)}`:'TRV —';
  return `${dist} · ${slope} · ${trv}`;
}
function updateStrategyCards(all=currentMission){
  ['balanced','risk','distance'].forEach(mode=>{
    const card=document.querySelector(`[data-strategy-card="${mode}"]`);
    const summary=document.querySelector(`[data-strategy-summary="${mode}"]`);
    const error=all?.errors?.[mode];
    if(summary){summary.textContent=error?ui('No disponible · revisa el mensaje','Unavailable · review the message'):strategySummary(all?.[mode]);summary.title=error||'';}
    const radio=document.querySelector(`input[name="mode"][value="${mode}"]`);if(radio)radio.disabled=busy||Boolean(error);
    if(card){
      const m=all?.[mode];
      card.classList.toggle('has-result',Boolean(m));
      card.classList.toggle('over-budget',Boolean(m?.overBudget));
      const selected=document.querySelector(`input[name="mode"][value="${mode}"]`)?.checked;
      card.classList.toggle('is-selected',Boolean(selected));
    }
  });
}
function strategiesEquivalent(all=currentMission){
  const ms=['distance','balanced','risk'].map(k=>all?.[k]).filter(Boolean);
  if(ms.length<3) return false;
  const distances=ms.map(m=>Number(m.metrics?.distanceKm)||0);
  const transits=ms.map(m=>Number(m.metrics?.avgTransitability)||0);
  const slopes=ms.map(m=>Number(m.metrics?.maxSlopeDeg)||0);
  return Math.max(...distances)-Math.min(...distances)<.03 && Math.max(...transits)-Math.min(...transits)<1 && Math.max(...slopes)-Math.min(...slopes)<.4;
}

function renderMission(mission){
  const m=mission.metrics,score=mission.score,available=mission.availableHours??availableMissionHours(mission.params||normalizeParams()),margin=available-mission.duration;
  const selectedLabel=mission.mode==='distance'?'Misión más directa':mission.mode==='risk'?'Misión de menor exposición':'Misión equilibrada';
  $('routeName').textContent=selectedLabel;
  $('routeStatus').textContent=mission.overBudget?'FUERA DE LÍMITE':Number.isFinite(score)?`${riskLabel(score).toUpperCase()} · ${score}/100`:'SIN EVALUACIÓN';
  $('routeStatus').className=`pill ${mission.overBudget?'warning':''}`;
  const order=(mission.orderOptimization?.optimizedOrder||[]).join(' → ');
  $('routeDescription').textContent=`${mission.targetCount??Math.max(0,(mission.sequence?.length||1)-1)} punto(s) · ${mission.legs.length} tramo(s) · ${mission.orderOptimization?.enabled?'orden optimizado automáticamente':'orden manual'}${order?` · ${order}`:''}. ${mission.strategyDescription}`;
  $('distance').textContent=Number.isFinite(m.distanceKm)?`${m.distanceKm.toFixed(2)} km`:'—';
  $('duration').textContent=formatHours(mission.duration);
  $('maxSlope').textContent=Number.isFinite(m.maxSlopeDeg)?`${m.maxSlopeDeg.toFixed(1)}°`:'—';
  $('gain').textContent=Number.isFinite(m.elevationChangeM)?`${Math.round(m.elevationChangeM)} m`:'—';
  $('riskNumber').textContent=Number.isFinite(score)?score:'—';$('riskLabel').textContent=Number.isFinite(score)?riskLabel(score):'Sin evaluación';$('riskBar').style.width=`${Number.isFinite(score)?score:0}%`;
  $('avgSlope').textContent=Number.isFinite(m.avgSlopeDeg)?`${m.avgSlopeDeg.toFixed(1)}°`:'—';$('segments').textContent=m.segments;$('legsCount').textContent=mission.legs.length;$('dwellTotal').textContent=`${Number.isFinite(mission.dwellMinutes)?mission.dwellMinutes:0} min`;$('missionMargin').textContent=formatSignedMargin(margin);
  if($('avgTransitability'))$('avgTransitability').textContent=Number.isFinite(m.avgTransitability)?`${m.avgTransitability.toFixed(0)}/100`:'—';if($('minTransitabilityMetric'))$('minTransitabilityMetric').textContent=Number.isFinite(m.minTransitability)?`${m.minTransitability.toFixed(0)}/100`:'—';if($('avgConfidence'))$('avgConfidence').textContent=Number.isFinite(m.avgConfidence)?`${m.avgConfidence.toFixed(0)}%`:'—';if($('minConfidenceMetric'))$('minConfidenceMetric').textContent=Number.isFinite(m.minConfidence)?`${m.minConfidence.toFixed(0)}%`:'—';if($('avgRoughnessDisplay'))$('avgRoughnessDisplay').textContent=Number.isFinite(m.avgRoughnessDeg)?`${m.avgRoughnessDeg.toFixed(1)}°`:'—';
  if($('maxRadialMetric')){
    const radial=$('maxRadialMetric');
    radial.textContent=Number.isFinite(m.maxRadialKm)?`${m.maxRadialKm.toFixed(2)} / ${Number(m.walkRadiusLimitKm).toFixed(0)} km`:'—';
    radial.dataset.state=m.walkbackExceeded?'over-walkback':m.radiusExceeded?'over-radius':'ok';
  }
  $('calcParams').textContent=`${mission.params.speed.toFixed(1)} km/h · EVA ${mission.params.evaTime.toFixed(1)} h · margen ${mission.params.returnMargin}% · pendiente ≤${mission.params.maxSlopeLimit.toFixed(0)}° · transit. ≥${mission.params.minTransitability.toFixed(0)} · calidad de muestreo ≥${mission.params.minConfidence.toFixed(0)}%`;
  if($('calcParams')&&Number.isFinite(mission.metrics?.maxRadialKm)){
    const over=mission.metrics.radiusExceeded?ui(` · EXCEDE el radio de caminata de ${Number(mission.metrics.walkRadiusLimitKm).toFixed(0)} km`,` · EXCEEDS the ${Number(mission.metrics.walkRadiusLimitKm).toFixed(0)} km walking radius`):'';
    $('calcParams').textContent+=` · ${ui('radio','radius')} ${mission.metrics.maxRadialKm.toFixed(2)} km${over}`;
  }
  if($('dataQualitySummary')){
    const samples=mission.legs.reduce((n,l)=>n+(l.sampling?.sampleCount||0),0),valid=mission.legs.reduce((n,l)=>n+(l.sampling?.validCount||0),0);
    const resolutions=mission.legs.map(l=>l.sampling?.maxResolutionM).filter(finiteValue);
    const spacing=Math.max(...mission.legs.map(l=>l.gridSpacingKm||0))*1000;
    $('dataQualitySummary').textContent=ui(`DEM solicitado: 200 m · resolución recibida: ${resolutions.length?Math.max(...resolutions).toFixed(0)+' m':'no informada'} · espaciamiento máximo de malla por tramo: ${spacing.toFixed(0)} m · cobertura: ${valid}/${samples} muestras. Calidad = completitud y densidad; no probabilidad de seguridad.`,`Requested DEM: 200 m · reported resolution: ${resolutions.length?Math.max(...resolutions).toFixed(0)+' m':'not reported'} · maximum median grid spacing across legs: ${spacing.toFixed(0)} m · coverage: ${valid}/${samples} samples. Quality = completeness and density; not a safety probability.`);
  }
  renderMissionTimeline(mission);updateRouteSequenceStrip(mission);renderTerrainProfile(mission);renderMissionAnalytics(mission);updateMissionHud(mission);updateHeaderStatus();updateStrategyCards(currentMission);drawPointMarkers();
  $('recalculate').disabled=false;$('saveMission').disabled=false;if($('lastCalculated'))$('lastCalculated').textContent=lastCalculatedAt?`Último cálculo: ${lastCalculatedAt.toLocaleString('es-NI',{dateStyle:'short',timeStyle:'short'})}`:'Último cálculo: —';
}

function renderMissionList(){
  const list=$('waypointList');list.innerHTML='';const auto=$('optimizeOrder')?.checked!==false,visit=optimizedVisitIndexMap();
  missionPoints.forEach((p,i)=>{
    const row=document.createElement('div');row.className='waypoint';const base=p.type==='base'||i===0,finalVisit=visit.get(pointCoordKey(p));
    const title=base?'BASE':finalVisit?`#${String(finalVisit).padStart(2,'0')}`:`P${i}`;
    const orderTag=base?'INICIO':finalVisit?'ORDEN CALCULADO':auto?'PENDIENTE DE CÁLCULO':'ORDEN MANUAL';
    row.innerHTML=`<div class="wpIndex">${title}</div><div class="wpMain"><input class="wpName" value="${escapeHtml(p.name)}" aria-label="Nombre del punto ${i+1}"><div class="wpMeta"><span>${formatLat(p.lat)} · ${formatLon(p.lon)}</span><span class="tag required">${orderTag}</span>${base?'':`<label class="dwellEdit">PARADA <input class="wpDwell" data-i="${i}" type="number" min="0" max="1440" step="1" value="${Math.max(0,Number(p.dwellMin)||0)}"> min</label>`}</div></div><div class="wpActions">${!base&&!auto?`<button title="Subir" data-action="up" data-i="${i}" ${i<=1?'disabled':''}>↑</button><button title="Bajar" data-action="down" data-i="${i}" ${i===missionPoints.length-1?'disabled':''}>↓</button>`:''}<button title="Eliminar" data-action="delete" data-i="${i}" ${base?'disabled':''}>×</button></div>`;
    list.appendChild(row);
  });
  list.querySelectorAll('.wpName').forEach((input,i)=>input.onchange=()=>{missionPoints[i].name=input.value.trim()||`Punto ${i}`;currentMission=null;updatePlanningUI();});
  list.querySelectorAll('.wpDwell').forEach(input=>input.onchange=()=>{const i=Number(input.dataset.i);missionPoints[i].dwellMin=Math.max(0,Math.min(1440,Number(input.value)||0));currentMission=null;updatePlanningUI();});
  list.querySelectorAll('[data-action]').forEach(btn=>btn.onclick=()=>handleWaypointAction(btn.dataset.action,Number(btn.dataset.i)));
}
function escapeHtml(s){return String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
function handleWaypointAction(action,i){
  if(action==='up'&&i>1)[missionPoints[i-1],missionPoints[i]]=[missionPoints[i],missionPoints[i-1]];
  if(action==='down'&&i>0&&i<missionPoints.length-1)[missionPoints[i+1],missionPoints[i]]=[missionPoints[i],missionPoints[i+1]];
  if(action==='delete'&&i>0)missionPoints.splice(i,1);
  currentMission=null;routeLayer?.getSource()?.clear();drawPointMarkers();renderMissionList();resetMetrics();updatePlanningUI();
}
function updatePlanningUI(){
  if(!currentMission){lastCalculatedAt=null;routeLayer?.getSource()?.clear();resetMetrics();}
  $('pointCount').textContent=missionPoints.length;$('calculate').disabled=busy||missionPoints.length<2;$('saveMission').disabled=busy||!currentMission;
  const hint=$('selectionHint'),hintBox=$('mapMissionHint');
  if(hint) hint.textContent=selecting?`Toca Marte para agregar el punto ${missionPoints.length+1}`:'';
  if(hintBox) hintBox.classList.toggle('is-visible',Boolean(selecting));
  const active=currentMission?.[document.querySelector('input[name="mode"]:checked')?.value||'balanced']||null;
  renderMissionList();renderMissionTimeline(active);updateRouteSequenceStrip(active);updateMissionHud(active);updateHeaderStatus();updateSettingsSummary();
  document.dispatchEvent(new CustomEvent("jezero:missionedited"));
}

function newMission(){ if(missionPoints.length&&!window.confirm(ui('¿Iniciar otra misión? El plan actual se reemplazará. Exporta una copia si deseas conservarlo.','Start another mission? The current plan will be replaced. Export a copy to keep it.')))return; missionPoints=[];currentMission=null;selecting=true;routeLayer.getSource().clear();drawPointMarkers();renderMissionList();resetMetrics();updatePlanningUI(); }
function setLanding(){
  const base={lat:LANDING.lat,lon:LANDING.lon,name:'Base: Perseverance',type:'base',required:true,dwellMin:0};
  // Perseverance queda automáticamente como P0/base de la misión.
  // Si ya hay objetivos, se conservan desde el segundo elemento en adelante.
  missionPoints = missionPoints.length ? [base, ...missionPoints.slice(1)] : [base];
  currentMission=null;
  routeLayer.getSource().clear();
  selecting=true;
  drawPointMarkers();
  renderMissionList();
  resetMetrics();
  updatePlanningUI();
  $('statusText').textContent='BASE DE PERSEVERANCE FIJADA · agrega los siguientes puntos en el mapa';
  map.getView().animate({center:[LANDING.lon,LANDING.lat],zoom:6,duration:450});
  showToast('Perseverance se marcó automáticamente como el punto BASE (P0).');
}
function resetMetrics(){
  if($('maxRadialMetric'))delete $('maxRadialMetric').dataset.state;
  ['maxRadialMetric','distance','duration','maxSlope','gain','avgSlope','segments','riskNumber','legsCount','dwellTotal','missionMargin','avgTransitability','minTransitabilityMetric','avgConfidence','minConfidenceMetric','__legacyScienceRemoved'].forEach(id=>{if($(id))$(id).textContent='—';});
  if($('routeName'))$('routeName').textContent=ui('Esperando misión','Waiting for mission');
  if($('routeDescription'))$('routeDescription').textContent=ui('Define una base y al menos un objetivo. Calcula para obtener resultados actuales.','Define a base and at least one target. Calculate to obtain current results.');
  if($('dataQualitySummary'))$('dataQualitySummary').textContent=ui('Calcula para consultar la cobertura y resolución del muestreo.','Calculate to inspect sampling coverage and resolution.');
  if($('routeStatus')){$('routeStatus').textContent=ui('SIN RUTA','NO ROUTE');$('routeStatus').className='pill';}
  if($('riskLabel'))$('riskLabel').textContent=ui('Sin evaluación','Not evaluated');
  if($('riskBar'))$('riskBar').style.width='0%';
  if($('calcParams'))$('calcParams').textContent='—';
  if($('lastCalculated'))$('lastCalculated').textContent=ui('Último cálculo: —','Last calculation: —');
  if($('recalculate'))$('recalculate').disabled=true;
  if($('saveMission'))$('saveMission').disabled=true;
  renderTerrainProfile(null); renderMissionAnalytics(null); renderMissionTimeline(null); updateRouteSequenceStrip(null); updateMissionHud(null); updateHeaderStatus(); updateStrategyCards(null);
}
function clearMission(){if(missionPoints.length&&!window.confirm(ui('¿Vaciar el plan actual? Guarda una copia antes de continuar.','Clear the current plan? Save a copy before continuing.')))return;missionPoints=[];currentMission=null;selecting=false;routeLayer.getSource().clear();drawPointMarkers();renderMissionList();resetMetrics();updatePlanningUI();}
function setBusy(b,msg){busy=b;$('calculate').disabled=b||missionPoints.length<2;$('recalculate').disabled=b||!currentMission;$('saveMission').disabled=b||!currentMission;if(msg)$('statusText').textContent=msg;else $('statusText').textContent='DATOS CARTOGRÁFICOS · NASA / USGS';}

function getHistory(){ try{return JSON.parse(localStorage.getItem(HISTORY_KEY)||'[]');}catch{return[];} }
function setHistory(items){localStorage.setItem(HISTORY_KEY,JSON.stringify(items.slice(0,12))); updateSettingsSummary();}

function pdfPointPayload(p){
  if(!p)return null;
  return {lat:Number(p.lat),lon:Number(p.lon),name:p.name,type:p.type==='base'?'base':'target',dwellMin:Number(p.dwellMin)||0,elevationM:finiteValue(p.elevationM)?Number(p.elevationM):null};
}

function pdfLegPayload(leg){
  if(!leg) return null;
  return {
    from:pdfPointPayload(leg.from),
    to:pdfPointPayload(leg.to),
    durationHours:Number(leg.durationHours),
    gridSpacingKm:finiteValue(leg.gridSpacingKm)?Number(leg.gridSpacingKm):null,
    sampling:{...(leg.sampling||{})},
    metrics:{...(leg.metrics||{})},
    path:(leg.path||[]).map((p,index)=>({
      index:index+1,
      lat:Number(p.lat),
      lon:Number(p.lon),
      elevationM:finiteValue(p.elevationM)?Number(p.elevationM):null,
      signedSlopeDeg:finiteValue(p.signedSlopeDeg)?Number(p.signedSlopeDeg):null,
      dataConfidence:finiteValue(p.dataConfidence)?Number(p.dataConfidence):null,
      baseTransitability:finiteValue(p.baseTransitability)?Number(p.baseTransitability):null,
      localRoughnessDeg:finiteValue(p.localRoughnessDeg)?Number(p.localRoughnessDeg):null,
      transitability:finiteValue(p.transitability)?Number(p.transitability):null,
      edgeConfidence:finiteValue(p.edgeConfidence)?Number(p.edgeConfidence):null
    }))
  };
}

function pdfStrategyPayload(m){
  if(!m)return null;
  return {mode:m.mode,strategyDescription:m.strategyDescription||'',duration:Number(m.duration),score:finiteValue(m.score)?Number(m.score):null,overBudget:Boolean(m.overBudget),availableHours:Number(m.availableHours),dwellMinutes:Number(m.dwellMinutes)||0,params:{...(m.params||{})},metrics:{...(m.metrics||{})},sequence:(m.sequence||[]).map(pdfPointPayload).filter(Boolean),includedPoints:(m.includedPoints||m.sequence||[]).map(pdfPointPayload).filter(Boolean),orderOptimization:m.orderOptimization?{...m.orderOptimization}:null,legs:(m.legs||[]).map(pdfLegPayload).filter(Boolean)};
}

async function exportMissionPdf(mode){
  const selected=currentMission?.[mode];
  if(!selected) return false;
  const now=new Date();
  const points=missionPoints.map(pdfPointPayload).filter(Boolean);
  const params={...selected.params};
  const report={
    fileName:`jezero-mision-${now.toISOString().slice(0,19).replace(/[T:]/g,'-')}`,
    reportId:`JEZERO-${now.toISOString().replace(/[-:TZ.]/g,'').slice(0,14)}`,
    generatedAt:now.toISOString(),
    selectedMode:mode,
    returnBase:selected.sequence?.at(-1)?.type==='base',
    params,
    mission:{
      name:getMissionSettings().missionName || ui(`Misión EVA · ${points.length} punto(s)`,`EVA Mission · ${points.length} point(s)`),
      code:getMissionSettings().missionCode || '',
      crew:getMissionSettings().crew || '',
      notes:getMissionSettings().notes || '',
      totalPoints:points.length,
      targetPoints:points.filter((p,i)=>i>0&&p.type!=='base').length,
      base:points.find(p=>p.type==='base')||points[0]||null,
      selectedStrategy:mode,
      calculationTimestamp:lastCalculatedAt?.toISOString?.()||null
    },
    dataSources:{
      elevation:window.JEZERO_DEMO?.enabled?'DEM sintético de demostración · NO SON DATOS NASA':'MDEM200M mediante ArcGIS ElevationLayer',
      cartography:'NASA / USGS / ESA / HRSC',
      map:'NASA Mars Trek / capas configuradas en JEZERO',
      marsRadiusKm:MARTIAN_RADIUS,
      demResolutionRequestedM:200,
      sampleQuality:'Índice de completitud y densidad del muestreo; no es una probabilidad de seguridad.'
    },
    survival:window.JEZERO_SURVIVAL?.getSnapshot?.()||null,
    software:{
      name:'JEZERO',
      version:JEZERO_UI_VERSION,
      algorithmVersion:ALGORITHM_VERSION,
      interfaceTheme:themeInfo().label,
      themeKey:themeInfo().key,
      reportLanguage:uiLang()
    },
    points,
    selected:pdfStrategyPayload(selected),
    strategies:['distance','balanced','risk'].map(k=>pdfStrategyPayload(currentMission[k])).filter(Boolean)
  };
  const res=await fetch('/api/mission-pdf',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(report)});
  if(!res.ok) throw new Error(ui(`No se pudo generar el PDF (${res.status}).`,`PDF generation failed (${res.status}).`));
  const blob=await res.blob();
  const url=URL.createObjectURL(blob);
  const a=document.createElement('a');
  a.href=url; a.download=report.fileName+'.pdf'; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(()=>URL.revokeObjectURL(url),1500);
  return true;
}

function saveHistoryEntry(mode){
  const items=getHistory(),now=new Date(),selected=currentMission?.[mode];
  const fingerprint=JSON.stringify({mode,returnBase:$('returnBase').checked,optimizeOrder:$('optimizeOrder')?.checked!==false,speed:Number($('speed').value),eva:Number($('evaTime').value),margin:Number($('returnMargin').value),maxSlope:Number($('maxSlopeLimit')?.value),minTransit:Number($('minTransitability')?.value),minConfidence:Number($('minConfidence')?.value),points:missionPoints.map(p=>[p.lat,p.lon,p.name,p.dwellMin])});
  const existing=items.find(x=>x.fingerprint===fingerprint);
  const meta=getMissionSettings(); const entry={id:existing?.id||`m-${Date.now()}`,date:now.toISOString(),name:meta.missionName||ui(`Misión ${now.toLocaleDateString('es-NI')} · ${missionPoints.length} puntos`,`Mission ${now.toLocaleDateString('en-US')} · ${missionPoints.length} points`),missionMeta:meta,mode,points:missionPoints.map(p=>({...p})),returnBase:$('returnBase').checked,optimizeOrder:$('optimizeOrder')?.checked!==false,speed:Number($('speed').value),evaTime:Number($('evaTime').value),returnMargin:Number($('returnMargin').value),...normalizeParams(),metrics:selected?.metrics||null,duration:selected?.duration||null,score:selected?.score??null,includedPoints:selected?.includedPoints||[],orderOptimization:selected?.orderOptimization||null,fingerprint};
  const filtered=items.filter(x=>x.id!==entry.id); filtered.unshift(entry); setHistory(filtered);renderHistory();
}
function renderHistory(){
  const box=$('historyList'); if(!box)return; const items=getHistory();
  if(!items.length){box.innerHTML=`<div class="historyEmpty">${ui('Aún no hay misiones guardadas.','No saved missions yet.')}</div>`;return;}
  const locale=uiLang()==='en'?'en-US':'es-NI';
  box.innerHTML=items.map(item=>`<div class="historyItem"><div><strong>${escapeHtml(item.name)}</strong><small>${new Date(item.date).toLocaleString(locale,{dateStyle:'short',timeStyle:'short'})} · ${item.points.length} ${ui('puntos','points')} · ${item.mode==='risk'?ui('Menor exposición','Lower exposure'):item.mode==='distance'?ui('Más directa','Most direct'):ui('Equilibrada','Balanced')}</small></div><div class="historyActions"><button data-load="${item.id}" title="${ui('Cargar','Load')}">${ui('Abrir','Open')}</button><button data-delete="${item.id}" title="${ui('Eliminar','Delete')}">×</button></div></div>`).join('');
  box.querySelectorAll('[data-load]').forEach(b=>b.onclick=()=>loadHistory(b.dataset.load)); box.querySelectorAll('[data-delete]').forEach(b=>b.onclick=()=>deleteHistory(b.dataset.delete));
}
function confirmMissionReplacement(){
  return !missionPoints.length||window.confirm(ui('¿Reemplazar el plan actual? Exporta una copia antes si deseas conservarlo.','Replace the current plan? Export a copy first if you want to keep it.'));
}
function loadHistory(id){
  const item=getHistory().find(x=>x.id===id); if(!item)return;
  let points;
  try{points=validation.points(item.points);if(!confirmMissionReplacement())return;if(item.missionMeta)setMissionSettings(item.missionMeta);}catch(e){showToast(e.message);return;}
  invalidateMission();missionPoints=points; $('returnBase').checked=item.returnBase!==false; if($('optimizeOrder'))$('optimizeOrder').checked=item.optimizeOrder!==false; $('speed').value=item.speed ?? 2; $('evaTime').value=item.evaTime ?? 6; $('returnMargin').value=item.returnMargin ?? 25; if($('maxSlopeLimit'))$('maxSlopeLimit').value=item.maxSlopeLimit ?? 20; if($('minTransitability'))$('minTransitability').value=item.minTransitability ?? 25; if($('minConfidence'))$('minConfidence').value=item.minConfidence ?? 20;
  const radio=document.querySelector(`input[name="mode"][value="${item.mode}"]`);if(radio)radio.checked=true;
  selecting=false;drawPointMarkers();renderMissionList();updatePlanningUI();centerGlobal();showToast('Misión cargada con sus parámetros originales. Pulsa “Calcular misión” o “Recalcular” para obtener el nuevo resultado.');
}
function deleteHistory(id){if(!window.confirm(ui('¿Borrar esta misión del historial local?','Delete this mission from the local history?')))return;setHistory(getHistory().filter(x=>x.id!==id));renderHistory();}



function getMissionSettings(){
  try{
    const saved=JSON.parse(localStorage.getItem(SETTINGS_KEY)||'{}');
    return {
      missionName:String(saved.missionName||'').trim(),
      missionCode:String(saved.missionCode||'').trim(),
      crew:String(saved.crew||'').trim(),
      notes:String(saved.notes||'').trim()
    };
  }catch{return {missionName:'',missionCode:'',crew:'',notes:''};}
}
function setMissionSettings(values={}){
  const current=getMissionSettings();
  const next={...current,...values};
  localStorage.setItem(SETTINGS_KEY,JSON.stringify(next));
  if($('missionNameSetting')) $('missionNameSetting').value=next.missionName||'';
  if($('missionCodeSetting')) $('missionCodeSetting').value=next.missionCode||'';
  if($('crewSetting')) $('crewSetting').value=next.crew||'';
  if($('missionNotesSetting')) $('missionNotesSetting').value=next.notes||'';
  updateSettingsSummary();
}
function readOperationalDefaults(){return normalizeParams();}
function getSavedDefaults(){ try{return JSON.parse(localStorage.getItem(DEFAULTS_KEY)||'null');}catch{return null;} }
function applyDefaults(values,{notify=true}={}){
  if(!values) return false;
  const mapIds={speed:'speed',evaTime:'evaTime',returnMargin:'returnMargin',maxSlopeLimit:'maxSlopeLimit',minTransitability:'minTransitability',minConfidence:'minConfidence'};
  Object.entries(mapIds).forEach(([k,id])=>{ if($(id) && finiteValue(values[k])) $(id).value=validation.parameters(values)[k]; });
  currentMission=null; routeLayer?.getSource()?.clear(); resetMetrics(); updatePlanningUI();
  if(notify) showToast(ui('Parámetros predeterminados aplicados al Planificador.','Default parameters applied to Mission Planner.'));
  return true;
}
function updateSettingsSummary(){
  const meta=getMissionSettings(), defs=getSavedDefaults(), hist=getHistory();
  if($('settingsMissionSummary')) $('settingsMissionSummary').textContent=meta.missionName || meta.missionCode || ui('Sin nombre definido','No name defined');
  if($('settingsDefaultsSummary')) $('settingsDefaultsSummary').textContent=defs ? `${defs.speed} km/h · EVA ${defs.evaTime} h · ${ui('margen','margin')} ${defs.returnMargin}%` : ui('Valores de fábrica','Factory values');
  if($('settingsHistorySummary')) $('settingsHistorySummary').textContent=`${hist.length} ${hist.length===1?ui('misión','mission'):ui('misiones','missions')}`;
  if($('settingsLanguageSummary')) $('settingsLanguageSummary').textContent=uiLang()==='en'?'English':'Español';
  if($('settingsThemeSummary')) $('settingsThemeSummary').textContent=themeInfo().label;
  updateHeaderStatus();
  if($('defaultsStatus')) $('defaultsStatus').textContent=defs ? `${ui('Guardados','Saved')}: ${defs.speed} km/h · EVA ${defs.evaTime} h · ${ui('pendiente','slope')} ≤ ${defs.maxSlopeLimit}° · ${ui('transitabilidad','traversability')} ≥ ${defs.minTransitability} · ${ui('calidad de muestreo','confidence')} ≥ ${defs.minConfidence}%` : ui('Usando valores de fábrica hasta que guardes un perfil.','Using factory values until you save a profile.');
}
function initializeSettings(){
  const meta=getMissionSettings();
  if($('missionNameSetting')) $('missionNameSetting').value=meta.missionName;
  if($('missionCodeSetting')) $('missionCodeSetting').value=meta.missionCode;
  if($('crewSetting')) $('crewSetting').value=meta.crew;
  if($('missionNotesSetting')) $('missionNotesSetting').value=meta.notes;
  if($('languageSetting')){
    $('languageSetting').value=uiLang();
    $('languageSetting').addEventListener('change',()=>window.JEZERO_I18N?.setLanguage?.($('languageSetting').value));
  }
  if($('routeAnimationSetting')){
    $('routeAnimationSetting').checked=routeAnimationEnabled;
    if(reducedMotionQuery.matches){
      $('routeAnimationSetting').checked=false;
      $('routeAnimationSetting').disabled=true;
      $('routeAnimationSetting').closest('.motionSetting')?.classList.add('is-disabled');
    }
    $('routeAnimationSetting').addEventListener('change',()=>setRouteAnimationEnabled($('routeAnimationSetting').checked));
  }
  reducedMotionQuery.addEventListener?.('change',ev=>{
    if(ev.matches){
      routeAnimationEnabled=false;
      if($('routeAnimationSetting')){$('routeAnimationSetting').checked=false;$('routeAnimationSetting').disabled=true;}
      $('routeAnimationSetting')?.closest('.motionSetting')?.classList.add('is-disabled');
    }else{
      if($('routeAnimationSetting')) $('routeAnimationSetting').disabled=false;
      $('routeAnimationSetting')?.closest('.motionSetting')?.classList.remove('is-disabled');
      routeAnimationEnabled=localStorage.getItem(ROUTE_ANIMATION_KEY)!=='off';
      if($('routeAnimationSetting')) $('routeAnimationSetting').checked=routeAnimationEnabled;
    }
    routeLayer?.changed?.(); map?.render?.();
  });
  window.addEventListener('jezero:languagechange',ev=>{
    if($('languageSetting')) $('languageSetting').value=ev.detail?.language||uiLang();
    updateSettingsSummary();
    renderHistory();
  });
  const defs=getSavedDefaults(); if(defs) applyDefaults(defs,{notify:false});
  ['missionNameSetting','missionCodeSetting','crewSetting','missionNotesSetting'].forEach(id=>$(id)?.addEventListener('input',()=>{
    setMissionSettings({missionName:$('missionNameSetting')?.value||'',missionCode:$('missionCodeSetting')?.value||'',crew:$('crewSetting')?.value||'',notes:$('missionNotesSetting')?.value||''});
  }));
  $('saveDefaultsBtn')?.addEventListener('click',()=>{
    const defs=readOperationalDefaults(); localStorage.setItem(DEFAULTS_KEY,JSON.stringify(defs)); updateSettingsSummary(); showToast(ui('Parámetros actuales guardados como predeterminados.','Current parameters saved as defaults.'));
  });
  $('restoreDefaultsBtn')?.addEventListener('click',()=>{
    const defs=getSavedDefaults(); if(!defs) return showToast(ui('Aún no has guardado parámetros predeterminados.','You have not saved default parameters yet.')); applyDefaults(defs);
  });
  $('exportMissionJson')?.addEventListener('click',exportMissionJson);
  $('importMissionJson')?.addEventListener('click',()=>$('importMissionFile')?.click());
  $('importMissionFile')?.addEventListener('change',importMissionJsonFile);
  $('clearHistoryBtn')?.addEventListener('click',()=>{
    if(!getHistory().length) return showToast(ui('El historial ya está vacío.','History is already empty.'));
    if(!window.confirm('¿Borrar todo el historial local de misiones?')) return;
    setHistory([]); renderHistory(); updateSettingsSummary(); showToast(ui('Historial local borrado.','Local history cleared.'));
  });
  updateSettingsSummary();
}
function exportMissionJson(){
  const mode=document.querySelector('input[name="mode"]:checked')?.value||'balanced';
  const payload={format:'JEZERO-MISSION',version:44,algorithmVersion:ALGORITHM_VERSION,exportedAt:new Date().toISOString(),missionMeta:getMissionSettings(),interface:{language:uiLang(),theme:themeInfo().key,routeAnimation:routeAnimationEnabled},points:missionPoints.map(p=>({lat:p.lat,lon:p.lon,name:p.name,type:p.type==='base'?'base':'target',dwellMin:Number(p.dwellMin)||0})),returnBase:$('returnBase')?.checked!==false,optimizeOrder:$('optimizeOrder')?.checked!==false,mode,params:readOperationalDefaults(),snapshot:currentMission?{calculatedAt:lastCalculatedAt?.toISOString(),algorithmVersion:ALGORITHM_VERSION,terrain:window.JEZERO_DEMO?.enabled?{source:'DEM sintético de demostración',resolutionM:200}:window.marsElevationInfo||null,survival:window.JEZERO_SURVIVAL?.getSnapshot?.()||null,strategies:validation.MODES.map(k=>pdfStrategyPayload(currentMission[k])).filter(Boolean),errors:{...currentMission.errors}}:null};
  const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}); const url=URL.createObjectURL(blob); const a=document.createElement('a');
  const code=(payload.missionMeta.missionCode||'mision').replace(/[^a-z0-9_-]+/gi,'-'); a.href=url; a.download=`jezero-${code}.json`; document.body.appendChild(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(url),1200);
  showToast(ui('Misión exportada a JSON.','Mission exported to JSON.'));
}
async function importMissionJsonFile(ev){
  const file=ev.target.files?.[0]; if(!file) return;
  try{
    if(file.size>5_000_000)throw new Error(ui('El archivo supera el límite de 5 MB.','The file exceeds the 5 MB limit.'));
    const data=validation.missionFile(JSON.parse(await file.text()));
    if(!confirmMissionReplacement())return false;
    if(data.missionMeta) setMissionSettings(data.missionMeta);
    invalidateMission();
    missionPoints=data.points;
    if(data.params) applyDefaults(data.params,{notify:false});
    if($('returnBase')) $('returnBase').checked=data.returnBase!==false; if($('optimizeOrder')) $('optimizeOrder').checked=data.optimizeOrder!==false;
    const radio=document.querySelector(`input[name="mode"][value="${data.mode}"]`); if(radio) radio.checked=true;
    currentMission=null; selecting=false; routeLayer?.getSource()?.clear(); drawPointMarkers(); renderMissionList(); resetMetrics(); updatePlanningUI(); centerGlobal();
    showToast(ui(`Misión importada: ${missionPoints.length} punto(s). Recalcula para actualizar resultados.`,`Mission imported: ${missionPoints.length} point(s). Recalculate to update results.`));
    try{
      if(data.interface?.theme) window.JEZERO_THEMES?.setTheme?.(data.interface.theme);
      if(typeof data.interface?.routeAnimation==='boolean') setRouteAnimationEnabled(data.interface.routeAnimation,{notify:false});
      if(data.interface?.language) window.JEZERO_I18N?.setLanguage?.(data.interface.language);
    }catch{showToast(ui('Misión importada; no se pudieron guardar las preferencias de interfaz.','Mission imported; interface preferences could not be saved.'));}
    return true;
  }catch(err){showToast(err.message||ui('No se pudo importar la misión.','The mission could not be imported.'));return false;}
  finally{ev.target.value='';}
}

function resetCoordinateForm(){
  if($('coordinateForm')) $('coordinateForm').reset();
  if($('coordTypeInput')) $('coordTypeInput').value='target';
  if($('coordDwellInput')) $('coordDwellInput').value='15';
  if($('coordinateError')){ $('coordinateError').textContent=''; $('coordinateError').classList.add('hide'); }
}
function parseCoordinateValue(value){return numericValue(value,NaN);}
function addPointFromCoordinates(){
  const lat=parseCoordinateValue($('coordLatInput')?.value);
  const lon=parseCoordinateValue($('coordLonInput')?.value);
  const nameInput=String($('coordNameInput')?.value||'').trim();
  const type=$('coordTypeInput')?.value==='base'?'base':'target';
  const dwellRaw=Number($('coordDwellInput')?.value);
  const dwellMin=Number.isFinite(dwellRaw)?Math.max(0,Math.min(1440,Math.round(dwellRaw))):15;
  const err=$('coordinateError');
  const fail=msg=>{ if(err){err.textContent=msg;err.classList.remove('hide');} showToast(msg); };

  if(!Number.isFinite(lat)||lat < -90 || lat > 90) return fail('La latitud debe estar entre −90° y 90°.');
  if(!Number.isFinite(lon)||lon < -180 || lon > 180) return fail('La longitud debe estar entre −180° y 180°.');

  const point={
    lat, lon,
    name:nameInput || (type==='base'?'Base de misión':`Objetivo ${Math.max(1,missionPoints.length)}`),
    type,
    required:true,
    dwellMin:type==='base' ? 0 : dwellMin
  };

  try{validation.points(type==='base'?[point,...missionPoints.filter(p=>p.type!=='base')]:[...missionPoints,point]);}catch(e){return fail(e.message);}
  if(type==='base'){
    const others=missionPoints.filter(p=>p.type!=='base');
    missionPoints=[point,...others];
    selecting=true;
    $('statusText').textContent='BASE DE COORDENADAS FIJADA · agrega los siguientes puntos';
    map.getView().animate({center:[lon,lat],zoom:Math.max(map.getView().getZoom(),3),duration:450});
    showToast(`${point.name} quedó establecida como BASE (P0).`);
  }else{
    missionPoints.push(point);
    selecting=true;
    $('statusText').textContent=`PUNTO AÑADIDO · ${point.name}`;
    map.getView().animate({center:[lon,lat],duration:350});
    showToast(`${point.name} se añadió a la misión.`);
  }

  currentMission=null;
  routeLayer.getSource().clear();
  drawPointMarkers();
  renderMissionList();
  resetMetrics();
  updatePlanningUI();
  resetCoordinateForm();
}

$('coordinateForm')?.addEventListener('submit',e=>{ e.preventDefault(); addPointFromCoordinates(); });
$('coordTypeInput')?.addEventListener('change',e=>{
  const base=e.target.value==='base';
    if($('coordDwellInput')) $('coordDwellInput').value=base?'0':'15';
});

$('mapInfoClose')?.addEventListener('click',closeReferencePopup);
$('mapInfoUseBase')?.addEventListener('click',()=>{
  const f=(document.querySelector(`[data-ref-layer]`) ? null : null);
  const kind=$('mapInfo')?.dataset.refKind, id=$('mapInfo')?.dataset.refId;
  const layer=kind==='landing'?landingLayer:knownLayer; const feature=layer?.getSource().getFeatures().find(x=>x.get('refId')===id);
  if(feature && kind==='landing') setBaseFromLanding(feature);
});
$('mapInfoAdd')?.addEventListener('click',()=>{
  const kind=$('mapInfo')?.dataset.refKind, id=$('mapInfo')?.dataset.refId;
  const layer=kind==='landing'?landingLayer:knownLayer; const feature=layer?.getSource().getFeatures().find(x=>x.get('refId')===id);
  if(feature) addReferenceToMission(feature);
});
$('landingSiteSelect')?.addEventListener('change',e=>{if(e.target.value)focusReference('landing',e.target.value);});
$('useSelectedLanding')?.addEventListener('click',()=>{
  const id=$('landingSiteSelect')?.value;
  if(!id){showToast(ui('Selecciona primero un sitio de aterrizaje.','Select a landing site first.'));return;}
  const f=landingLayer.getSource().getFeatures().find(x=>x.get('refId')===id); if(f) setBaseFromLanding(f);
});
const hudPrefKey='jezero-hud-v36';
const hudEl=$('missionHud'),hudToggle=$('missionHudToggle');
if(hudEl&&hudToggle){
  const pref=localStorage.getItem(hudPrefKey); if(pref==='expanded'){hudEl.classList.remove('is-compact');hudToggle.setAttribute('aria-expanded','true');hudToggle.textContent='⌃';}
  hudToggle.addEventListener('click',()=>{const compact=hudEl.classList.toggle('is-compact');hudToggle.setAttribute('aria-expanded',String(!compact));hudToggle.textContent=compact?'⌄':'⌃';localStorage.setItem(hudPrefKey,compact?'compact':'expanded');});
}
window.addEventListener('jezero:themechange',()=>renderMissionAnalytics(selectedMission()));
window.addEventListener('jezero:languagechange',()=>renderMissionAnalytics(selectedMission()));
$('analyticsStrategySelect')?.addEventListener('change',e=>activateStrategyFromAnalytics(e.target.value));
$('analyticsClearSelection')?.addEventListener('click',clearAnalyticsSelection);
window.addEventListener('jezero:modulechange',e=>{if(e.detail?.module!=='analysis')clearAnalyticsSelection();});

$('planMode').onclick=newMission;
$('calculate').onclick=()=>calculateMission();
$('clearRoute').onclick=clearMission;
$('recalculate').onclick=()=>calculateMission({saveHistory:true});
$('saveMission').onclick=async()=>{
  if(!currentMission||busy)return;
  const mode=document.querySelector('input[name="mode"]:checked').value;
  try{
    saveHistoryEntry(mode);
    setBusy(true,'Guardando misión y generando informe PDF…');
    await exportMissionPdf(mode);
    setBusy(false,'MISIÓN GUARDADA · INFORME PDF DESCARGADO · NASA / USGS');
    showToast(ui('Misión guardada en el historial y PDF generado.','Mission saved to history and PDF generated.'));
  }catch(err){
    setBusy(false,'DATOS CARTOGRÁFICOS · NASA / USGS');
    showToast(err.message||ui('No se pudo generar el PDF.','The PDF could not be generated.'));
  }
};
$('addBase').onclick=()=>{if(!missionPoints.length){showToast(ui('Crea al menos un punto para fijarlo como base.','Create at least one point before setting a base.'));return;}missionPoints[0]={...missionPoints[0],name:'Base de misión',type:'base',required:true,dwellMin:0};currentMission=null;drawPointMarkers();renderMissionList();updatePlanningUI();};
function syncLayerControls(layer,visible){
  document.querySelectorAll(`[data-layer="${layer}"],[data-quick-layer="${layer}"]`).forEach(control=>{ if(control.checked!==visible) control.checked=visible; });
}
function applyLayerVisibility(layer,visible){
  activeLayerNames[visible?'add':'delete'](layer);
  syncLayerControls(layer,visible);
  if(layer==='slope'){
    slopeLayer?.setVisible(visible);
    slopeLayer?.getSource().clear();
    if(visible){
      setLayerStatus('slope',map?.getView().getZoom()>=2.2?'CARGANDO…':'ACERCA PARA ANALIZAR',map?.getView().getZoom()>=2.2?'loading':'ready');
      refreshDerivedLayers(true);
    } else setLayerStatus('slope','OCULTA','ready');
  }
  if(layer==='roughness'){
    roughnessLayer?.setVisible(visible);
    roughnessLayer?.getSource().clear();
    if(visible){
      setLayerStatus('roughness',map?.getView().getZoom()>=2.2?'CARGANDO…':'ACERCA PARA ANALIZAR',map?.getView().getZoom()>=2.2?'loading':'ready');
      refreshDerivedLayers(true);
    } else setLayerStatus('roughness','OCULTA','ready');
  }
  if(layer==='known'){
    knownLayer?.setVisible(visible);
    setLayerStatus('known',visible?'ACTIVA':'OCULTA',visible?'live':'ready');
    if(visible) scheduleNomenclatureRefresh(80); else removeDynamicNomenclature();
  }
  if(layer==='landing'){
    landingLayer?.setVisible(visible);
    setLayerStatus('landing',visible?'ACTIVA':'OCULTA',visible?'live':'ready');
  }
  if(layer==='route'){
    routeLayer?.setVisible(visible);
    setLayerStatus('route',visible?'ACTIVA':'OCULTA',visible?'live':'ready');
  }
  if(layer==='points'){
    markerLayer?.setVisible(visible);
    setLayerStatus('points',visible?'ACTIVA':'OCULTA',visible?'live':'ready');
  }
}
document.querySelectorAll('[data-layer],[data-quick-layer]').forEach(el=>el.addEventListener('change',()=>applyLayerVisibility(el.dataset.layer||el.dataset.quickLayer,el.checked)));

document.querySelectorAll('input[name="mode"]').forEach(el=>el.onchange=()=>{updateStrategyCards(currentMission);if(currentMission?.[el.value]){const mode=el.value;renderMission(currentMission[mode]);drawMissionRoutes(currentMission,mode);if(strategiesEquivalent(currentMission))showToast(ui('Las tres estrategias son prácticamente equivalentes en este terreno y con estos límites.','The three strategies are practically equivalent on this terrain with these limits.'));}});
$('returnBase').onchange=()=>{currentMission=null;routeLayer?.getSource()?.clear();resetMetrics();updatePlanningUI();};
$('optimizeOrder')?.addEventListener('change',()=>{currentMission=null;routeLayer?.getSource()?.clear();resetMetrics();updatePlanningUI();showToast($('optimizeOrder').checked?ui('Orden automático activado. JEZERO elegirá la mejor secuencia al calcular.','Automatic ordering enabled. JEZERO will choose the best sequence when calculating.'):ui('Orden manual activado. JEZERO respetará la lista de puntos.','Manual ordering enabled. JEZERO will respect the point list.'));});
['speed','evaTime','returnMargin','maxSlopeLimit','minTransitability','minConfidence'].forEach(id=>$(id).addEventListener('input',()=>{invalidateMission();$('statusText').textContent=ui('PARÁMETROS CAMBIADOS · vuelve a calcular','PARAMETERS CHANGED · recalculate');}));
function showToast(msg){$('toast').textContent=msg;$('toast').classList.remove('hide');clearTimeout(showToast.t);showToast.t=setTimeout(()=>$('toast').classList.add('hide'),5000);}

const BASE_MAP_MODES = new Set(['viking','mola','hybrid']);
function updateBaseMapStatus(mode){
  document.querySelectorAll('[data-base-status]').forEach(el=>{
    const active = el.dataset.baseStatus===mode || (mode==='hybrid' && el.dataset.baseStatus==='hybrid');
    el.textContent=active?'ACTIVA':'DISPONIBLE';
    el.className=`layerStatus ${active?'live':'ready'}`;
  });
  document.querySelectorAll('[data-base-map]').forEach(el=>{el.checked=el.dataset.baseMap===mode;});
  if($('baseMapMode') && $('baseMapMode').value!==mode) $('baseMapMode').value=mode;
}
function setBaseMapMode(mode,{persist=true}={}){
  if(!BASE_MAP_MODES.has(mode)) mode='viking';
  imageryLayer?.setVisible(mode==='viking'||mode==='hybrid');
  molaLayer?.setVisible(mode==='mola'||mode==='hybrid');
  imageryLayer?.setOpacity(1);
  molaLayer?.setOpacity(mode==='hybrid'?0.34:1);
  updateBaseMapStatus(mode);
  document.querySelector('.mapPanel')?.setAttribute('data-base-map',mode);
  if(persist) localStorage.setItem(BASE_MAP_KEY,mode);
  window.JEZERO_IMAGERY?.setMode(mode);
  requestAnimationFrame(()=>map?.render?.());
}
document.querySelectorAll('[data-base-map]').forEach(el=>el.addEventListener('change',()=>{if(el.checked)setBaseMapMode(el.dataset.baseMap);}));

const MAP_VISUAL_MODES = new Set(['geology','relief','mono','eva']);
function setMapVisualMode(mode,{persist=true}={}){
  if(!MAP_VISUAL_MODES.has(mode)) mode='geology';
  const panel=document.querySelector('.mapPanel');
  if(panel) panel.dataset.mapView=mode;
  if($('mapVisualMode') && $('mapVisualMode').value!==mode) $('mapVisualMode').value=mode;
  if(persist) localStorage.setItem(MAP_VIEW_KEY,mode);
  requestAnimationFrame(()=>map?.render?.());
}
function currentPanelState(){
  return {left:!document.body.classList.contains('left-panel-hidden'),right:!document.body.classList.contains('right-panel-hidden')};
}
function updatePanelControls(){
  const state=currentPanelState();
  const l=$('toggleLeftPanel'), r=$('toggleRightPanel'), focus=$('focusMap');
  if(l){l.textContent=state.left?'‹':'›';l.title=state.left?ui('Ocultar panel izquierdo','Hide left panel'):ui('Mostrar panel izquierdo','Show left panel');l.setAttribute('aria-label',l.title);}
  if(r){r.textContent=state.right?'›':'‹';r.title=state.right?ui('Ocultar panel derecho','Hide right panel'):ui('Mostrar panel derecho','Show right panel');r.setAttribute('aria-label',r.title);}
  if(focus){focus.classList.toggle('is-active',!state.left&&!state.right);const label=focus.querySelector('span');if(label)label.textContent=!state.left&&!state.right?ui('Paneles','Panels'):ui('Mapa','Map');focus.title=!state.left&&!state.right?ui('Mostrar paneles','Show panels'):ui('Ocultar ambos paneles','Hide both panels');}
}
function setPanelState(left,right,{persist=true}={}){
  document.body.classList.toggle('left-panel-hidden',!left);
  document.body.classList.toggle('right-panel-hidden',!right);
  updatePanelControls();
  if(persist) localStorage.setItem(PANEL_STATE_KEY,JSON.stringify({left,right}));
  requestAnimationFrame(()=>{map?.updateSize?.();setTimeout(()=>map?.updateSize?.(),240);});
}
function initPanelControls(){
  let state={left:true,right:true};
  try{state={...state,...JSON.parse(localStorage.getItem(PANEL_STATE_KEY)||localStorage.getItem('jezero-panel-state-v33')||'{}')};}catch{}
  setPanelState(state.left!==false,state.right!==false,{persist:false});
  $('toggleLeftPanel')?.addEventListener('click',()=>{const s=currentPanelState();setPanelState(!s.left,s.right);});
  $('toggleRightPanel')?.addEventListener('click',()=>{const s=currentPanelState();setPanelState(s.left,!s.right);});
  $('focusMap')?.addEventListener('click',()=>{const s=currentPanelState();const any=s.left||s.right;setPanelState(!any,!any);});
}
window.JEZERO_PANELS = Object.freeze({
  get: currentPanelState,
  set: (left,right)=>setPanelState(Boolean(left),Boolean(right)),
  toggleBoth: ()=>{const s=currentPanelState();const any=s.left||s.right;setPanelState(!any,!any);},
  open: ()=>setPanelState(true,true),
  close: ()=>setPanelState(false,false)
});

function initMapVisualControls(){
  setBaseMapMode(localStorage.getItem(BASE_MAP_KEY)||localStorage.getItem('jezero-base-map-v33')||'viking',{persist:false});
  $('baseMapMode')?.addEventListener('change',e=>setBaseMapMode(e.target.value));
  setMapVisualMode(localStorage.getItem(MAP_VIEW_KEY)||localStorage.getItem('jezero-map-view-v33')||'geology',{persist:false});
  $('mapVisualMode')?.addEventListener('change',e=>setMapVisualMode(e.target.value));
  const drawer=$('mapLayerDrawer'), toggle=$('toggleLayerDrawer');
  const close=()=>{drawer?.classList.remove('is-open');drawer?.setAttribute('aria-hidden','true');toggle?.setAttribute('aria-expanded','false');};
  const open=()=>{drawer?.classList.add('is-open');drawer?.setAttribute('aria-hidden','false');toggle?.setAttribute('aria-expanded','true');};
  toggle?.addEventListener('click',()=>drawer?.classList.contains('is-open')?close():open());
  $('closeLayerDrawer')?.addEventListener('click',close);
  document.addEventListener('pointerdown',e=>{if(drawer?.classList.contains('is-open')&&!drawer.contains(e.target)&&e.target!==toggle)close();});
  ['slope','roughness','route','points','known','landing'].forEach(layer=>{
    const source=document.querySelector(`[data-layer="${layer}"]`); if(source) syncLayerControls(layer,source.checked);
  });
}

const toggleMapLegend=$('toggleMapLegend');
const mapLegend=$('mapLegend');
toggleMapLegend?.addEventListener('click',()=>{
  const collapsed=mapLegend?.classList.toggle('is-collapsed');
  if(toggleMapLegend){ toggleMapLegend.textContent=collapsed?'＋':'−'; toggleMapLegend.setAttribute('aria-expanded',String(!collapsed)); }
});


window.addEventListener('jezero:modulechange',()=>{
  requestAnimationFrame(()=>{ map?.updateSize(); updateMapScale(); });
});

(async()=>{try{D=await fetch(DATA_URL).then(r=>r.json());await prepareLayerSources();initMap();initPanelControls();initMapVisualControls();initializeSettings();setLayerStatus('route','ACTIVA','live');setLayerStatus('points','ACTIVA','live');renderMissionList();renderHistory();updatePlanningUI();populateReferenceLayers();setLayerStatus('known','ACTIVA','live');scheduleNomenclatureRefresh(250);setLayerStatus('landing','ACTIVA','live');$('statusText').textContent='DATOS CARTOGRÁFICOS · NASA / USGS';}catch(e){showToast(ui('No se pudo cargar la configuración.','Configuration could not be loaded.'));console.error(e);}})();

// Presentation actions expose existing operations without duplicating mission state.
function missionDraft(){return {format:'JEZERO-MISSION',version:44,missionMeta:getMissionSettings(),interface:{language:uiLang(),theme:themeInfo().key},points:missionPoints.map(p=>({lat:p.lat,lon:p.lon,name:p.name,type:p.type==='base'?'base':'target',dwellMin:Number(p.dwellMin)||0})),returnBase:$('returnBase').checked,optimizeOrder:$('optimizeOrder')?.checked!==false,mode:document.querySelector('input[name="mode"]:checked')?.value||'balanced',params:readOperationalDefaults()};}
window.JEZERO_UI_ACTIONS=Object.freeze({
  missionDraft,
  async loadMissionPayload(payload){validation.missionFile(payload);const loaded=await importMissionJsonFile({target:{files:[new File([JSON.stringify(payload)],'mission.json',{type:'application/json'})],value:''}});if(loaded)fitCurrentMission();return loaded;},
  selectedMission:()=>selectedMission(),
  allMissions:()=>currentMission,
  missionSnapshot:()=>currentMission?{selectedMode:selectedMission()?.mode,strategies:validation.MODES.map(k=>pdfStrategyPayload(currentMission[k])).filter(Boolean)}:null,
  selectMode:mode=>activateStrategyFromAnalytics(mode),
  previewProgress:fraction=>{const points=analyticsSeries(selectedMission());const point=points[Math.round((points.length-1)*fraction)];if(point)syncAnalyticsCursor(point,{pin:false});},
  beginMapSelection(){selecting=true;updatePlanningUI();showToast(ui('Toca el mapa para añadir un punto. Los puntos actuales se conservan.','Tap the map to add a point. Existing points are preserved.'));},
  async loadExample(){
    const response=await fetch('/examples/04-eva-01-jezero.json');
    if(!response.ok)throw new Error(ui('No se pudo cargar el ejemplo.','The example could not be loaded.'));
    const text=await response.text();validation.missionFile(JSON.parse(text));
    const loaded=await importMissionJsonFile({target:{files:[new File([text],'jezero-eva-01.json',{type:'application/json'})],value:''}});
    if(!loaded)return false;
    map?.getView()?.cancelAnimations();map?.getView()?.animate({center:[77.4253,18.4448],zoom:12,duration:350});
  }
});
